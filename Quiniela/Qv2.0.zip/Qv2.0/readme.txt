q2.0 Programa de Generaci�n de Apuestas quiniel�sticas.
Copyright Victor Rodr�guez Doncel 2005
======================================


cambie el archivo "pronostico.txt" con los pron�sticos que usted considere y ejecute el programa. No hay manual, as� que s�rvase de su intuici�n.