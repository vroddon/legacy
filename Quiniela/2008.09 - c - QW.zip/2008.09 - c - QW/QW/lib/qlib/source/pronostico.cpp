#include <stdlib.h>
#include <math.h>
#include "pronostico.h"

/*
Esta funcion consigue dar un pronostico perfecto:
- que sume cien
- que sean enteros
- que ninguno sea cero

ppp = 99
33,3
33,3
33,4
gpp = 100
33,9
33,1
33,0
ggp = 101
33,9
33,9
32,2
ggg = 101
33,6
33,6
32,8
*/
bool CPronostico::Redondear(float f1, float fx, float f2)
{
	//normalizacion
	float total=f1+f2+fx;
	if (total==0) return false;
	f1=f1*100/total;
	fx=fx*100/total;
	f2=f2*100/total;
	CPronostico pronoFinal;
	float fBestError=100;
	int i,j,k;
	for (i=0;i<2;i++)
	{
		p1= i ? ceil(f1) : floor(f1);
		for (j=0;j<2;j++)
		{
			px= j ? ceil(fx) : floor(fx);
			for (k=0;k<2;k++)
			{
				p2= k ? ceil(f2) : floor(f2);
				if (((p1+px+p2)==100) && p1 && px && p2)
				{
					float fError=abs(p1-f1) + abs(px-fx) + abs(p2-f2);
					if (fError < fBestError)
					{
						fBestError=fError;
						pronoFinal=CPronostico(p1,px,p2);
					}
				}
			}
		}
	}
	if (fBestError==100) return false; 
	p1=pronoFinal.p1;
	px=pronoFinal.px;
	p2=pronoFinal.p2;
	return true;
}

bool CPronostico::FromRatio(float f1, float fx, float f2)
{
	float if1=1/f1;
	float ifx=1/fx;
	float if2=1/f2;
	float ftotal=if1+ifx+if2;
	if1=if1/ftotal;
	ifx=ifx/ftotal;
	if2=if2/ftotal;
	return Redondear(if1,ifx,if2);

}
