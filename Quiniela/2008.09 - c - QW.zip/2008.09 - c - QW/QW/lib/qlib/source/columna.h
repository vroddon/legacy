#pragma once

#include "pronostico.h"
#include <iostream>
#include <vector>

static long potencias3[]={1,3,9,27,81,243,729,2187,6561,19683,59049,177147,531441,1594323};
static long potencias2[]={2,4,8,16,32,64,128,256,512,1024,2048,4096,8192,16384};

using namespace std;

typedef char signo;

/** 
 Representa una columna
*/
class CColumna
{
public:
	/**
	* creates a column
	*/
	CColumna();

	/**
	* creates the n-th column
	* Columna 0: 11111111111111
	* Columna 1: 1111111111111X
	* columna N: 22222222222222
	*/
	CColumna(long l);

	/**
	* creates the given column
	*/
	CColumna(signo lista[]);

	/**
	* creates the given column
	*/
	CColumna(string sCol);

	/**
	* Dos columnas son iguales con tal de que sus signos sean iguales
	*/
	inline bool operator == (const CColumna &b) const { return (Match(b)==14);}

	/** 
	* Genera una columna aleatoriamente en funcion de la probabilidad que se le pasa
	* el pronostico ser� normalizado
	* la distribuci�n ser� uniforme, donde cada signo aparece con la probabilidad aqui dada.
	* @param a Pronostico
	*/
	void Random(CPronostico a[14]);

	/**
	* Indica cu�ntos resultados coinciden entre dos columnas (0-14)
	* Por ejemplo:
	* 11111111111111  --> This column
	* XXXXXXXXXXX111  --> s2 column
	* Result: 3
	*/
	int Match(const CColumna s2) const;

	/**
	* Muta un partido aleatoriamente en funcion de su probabilidad. 
	* La funcion podria fallar si hay un �nico signo posible.
	*/
	void Mutar(CPronostico a[14]);

	/**
	* Crea una columna a partir de su ordinal
	*/
	void DeEntero(long l);

	/* 
	* Calcula el valor seg�n el criterio de probabilidad dado
	*/
	long Valorar(CPronostico a[14]) const;

	/* 
	* Cuenta el n�mero de unos
	* Ej:
	* XX111XX2222222
	* Result is 3
	*/
	int Unos() const;

	/* 
	* Cuenta el numero de equis
	* Ej:
	* XX111XX2222222
	* Result is 4
	*/
	int Equis() const ;

	/* 
	* Cuenta el numero de doses
	* Ej:
	* XX111XX2222222
	* Result is 7
	*/
	int Doses() const;

	/**
	* Cuenta el numero de variantes
	* Ej:
	* XX111XX2222222
	* Result is 11
	*/
	int Variantes() const;

	/*
	* Gets a string representing the Column
	* Ej:
	* XX111XX2222222
	* Result is "XX111XX2222222", with no paddings etc.
	*/
	string getString() const;

	/**
	* The probability of getting 14 hits, given probability, given in db
	*/
	float Probabilidad14(CPronostico a[14], bool bLogaritmico=true) const;

	double getProbabilidadApostada(CPronostico pronosticocateto[14]);
	double getProbabilidadReal(CPronostico pronostico[14]);
	double getPremioEsperado(int nivel);
	double getRentabilidadPorNivel(int nivel);

	/**
	* Calcula la rentabilidad de la columna
	* pronostico es el pronostico jugado por la masa, lease quiniela lector marca
	* pronosticocateto es el pronostico real, obtenido de las casas de apuestas.
	*/
	double Rentabilidad(CPronostico pronostico[14],CPronostico pronosticocateto[14]);

	friend ostream &operator<<(ostream &o,CColumna sol);
	friend istream &operator>>(istream &is,CColumna &sol);

	/**
	* Devuelve los vecinos a una distancia iDistancia
	* En la primera llamada, iFrom=0. La funci�n es recursiva y utilizar� este par�metro
	*/
	vector<CColumna> getVecinos(int distancia, int iFrom=0);


	/*
	* Gets a joker variable about the column. 
	*/
	char getFlag() const {return m_joker;}

	/*
	* Sets a joker variable in the column. 
	*/
	void setFlag(char b) {m_joker=b;}

	/**
	* Establece en j el signo de la fila i
	*/
	inline void var(int i, signo j){_var[i]=j;} 

	/**
	* Devuelve el signo de la casilla i
	*/
	inline signo var(int i) const {return _var[i];}

	/**
	* Devuelve el signo de la casilla i
	*/
	inline const signo operator[](int i) const {return _var[i];}

	// Valoraci�n de la columna
//	int m_valor; 

	float m_fProb;	//probabilidad de salir de 14

//	float m_fFreq;	//frequencia con la que ser� apostada

	float m_fRent;

	float getRentabilidad(bool bDoNotCalculate=true);

private:
	signo _var[14];
	char m_joker;
};

char getCharFromSigno(signo c);
void NormalizarPronostico(CPronostico a[14], CPronostico ap[14]);


