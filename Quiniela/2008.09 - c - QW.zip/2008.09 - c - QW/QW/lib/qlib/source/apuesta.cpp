#pragma once
#include <sstream>
#include <iostream>
#include <fstream>
#include <math.h>
#include <algorithm>
#include "conf.h"
#ifndef NOWIN
	#include <afxwin.h>
#endif

using namespace std;
#include "apuesta.h"



CPronostico esperanza[14];
CPronostico CApuesta::pronostico[14];
CPronostico CApuesta::pronosticocateto[14];


// 144 apuestas:
// 144 - 4032 - 52416 - (52889 de 56592)
//
//
int fFlageadas(CColumna col,void * f);

CPremios::CPremios()
{
	ResetPremios();
}

void CPremios::ResetPremios()
{
	iRecaudacion=0;
	iPremio14=0;iPremio13=0;iPremio12=0;iPremio11=0;iPremio10=0;
	m_iAcertantes14=0;m_iAcertantes13=0;m_iAcertantes12=0;m_iAcertantes11=0;m_iAcertantes10=0;
	iPremio15=0;m_iAcertantes15=0;
	m_iPrecio=50;
}

CApuesta::CApuesta(int _ncols) : ncols(_ncols) 
{
	cols=(CColumna *)malloc(sizeof(CColumna)*ncols);
}

CApuesta::CApuesta(const CApuesta &apuesta)
{
	
	cols=(CColumna *)malloc(sizeof(CColumna)*apuesta.ncols);
	memcpy(cols,apuesta.cols,apuesta.ncols*sizeof(CColumna));
	ncols=apuesta.ncols;
}

CApuesta::~CApuesta()
{
	free(cols);
}

ostream &operator<<(ostream &o,CColumna sol)
{
	for (int i=0;i<14;i++)
		if ((sol.var(i))== UNO)
			o << '1';
		else if ((sol.var(i))== EQUIS)
			o << 'X';
		else
			o << '2';
	return o;
}

ostream &operator<<(ostream &o,CApuesta &a)
{
	for (int i=0;i<a.ncols;i++)
	{
		o << a.cols[i];
		o << '\n';
	}

	return o;
}
istream &operator>>(istream &is,CApuesta &a)
{
	while(!is.eof())
	{
		CColumna colu;
		is >> colu;
		if (is.eof())
			break;
		a.InsertarAlloc(colu);
	}

	return is;
}

void Probabilidades(CColumna &s2,int *catorce, int *trece, int *doce)
{
	*catorce=0;*trece=0;*doce=0;
	for (int i=0;i<COMBINACIONES;i++)
	{
		CColumna s1;
		s1.DeEntero(i);
		int q=s1.Match(s2);
		if (q==14) (*catorce)++;
		if (q==13) (*trece)++;
		if (q==12) (*doce)++;
	}
}



//para una sol tocada por varias cols, solo se anota uno a la mejor de todas.
int CApuesta::Probabilidades(int *catorce, int *trece, int *doce, int *once, int *diez,int criterio)
{
	int afortunadas=0;
	bool buena;
	*catorce=0;*trece=0;*doce=0;*once=0;*diez=0;
	for (int i=0;i<COMBINACIONES;i++)
	{
		CColumna s1;
//		if (i%10000==0)	{CString cad;cad.Format("%d %d",i,ncols);m_rotulo.SetWindowText(cad);}
		s1.DeEntero(i);
		buena=false;
		bool bcat=false, btrec=false,bdoc=false,bonc=false,bdiez=false;
		for (int j=0;j<ncols;j++)
		{
			int q=s1.Match(cols[j]);
			if (q==14) bcat=true;
			if (q==13) btrec=true;
			if (q==12) bdoc=true;
			if (q==11) bonc=true;
			if (q==10) bdiez=true;
			if (q>=criterio) buena=true;
		}
			 if (bcat) (*catorce)++;
		else if (btrec) (*trece)++;
		else if (bdoc) (*doce)++;
		else if (bonc) (*once)++;
		else if (bdiez) (*diez)++;
		if (!(i%10000))
			::SendMessage(AfxGetMainWnd()->GetSafeHwnd(),MSGQ_PROGRESS,100*i/COMBINACIONES,0);
		if (buena) afortunadas++;
	}
	::SendMessage(AfxGetMainWnd()->GetSafeHwnd(),MSGQ_PROGRESS,0,0);

	return afortunadas;
}

int CApuesta::getMinDist(int k)
{
	if (ncols<=k)
		return -1;
	CColumna s=cols[k];
	int mindist=0;
	for (int i=0;i<ncols;i++)
	{
		int aux=s.Match(cols[i]);
		if (aux>mindist && (i !=k) )
			mindist=aux;
	}
	return 14-mindist;
}

int CApuesta::getMinDist(CColumna s)
{
	int mindist=0;
	for (int i=0;i<ncols;i++)
	{
		int aux=s.Match(cols[i]);
		if (aux>mindist && aux!=14)
			mindist=aux;
	}
	return 14-mindist;
}

bool CApuesta::FastMinDist(CColumna s,int criterio)
{
	for (unsigned int i=0;i<ncols;i++)
	{
		int q=s.Match(cols[i]);
		if (q >= (14 - criterio))
			return true;
	}
	return false;
}

int CApuesta::Escrutar(CColumna s, signo pleno15, CPremios premio)
{
	m_iAciertos15=0;m_iAciertos14=0;
	m_iAciertos13=0;m_iAciertos12=0;
	m_iAciertos11=0;m_iAciertos10=0;

	for (unsigned int i=0;i<ncols;i++)
	{
		if (!(i%1000)) ::SendMessage(AfxGetMainWnd()->GetSafeHwnd(),MSGQ_PROGRESS,100*i/ncols,0);

		int q=s.Match(cols[i]);
		if (q==14) 
		{	
			m_iAciertos14++;
			if (pleno15==UNO)		//condicion arbitraria: yo siempre juego el p15 al 1.
				m_iAciertos15++;
		}
		if (q==13) m_iAciertos13++;
		if (q==12) m_iAciertos12++;
		if (q==11) m_iAciertos11++;
		if (q==10) m_iAciertos10++;
	}
	::SendMessage(AfxGetMainWnd()->GetSafeHwnd(),MSGQ_PROGRESS,0,0);

	m_iPremioTotal=premio.iPremio10*m_iAciertos10;
	m_iPremioTotal+=premio.iPremio11*m_iAciertos11;
	m_iPremioTotal+=premio.iPremio12*m_iAciertos12;
	m_iPremioTotal+=premio.iPremio13*m_iAciertos13;
	m_iPremioTotal+=premio.iPremio14*m_iAciertos14;
	m_iPremioTotal+=premio.iPremio15*m_iAciertos15;
	return m_iPremioTotal;
}

void CApuesta::ResetPronostico(CPronostico p[14])
{
	for (int i=0;i<14;i++)
		p[i]=CPronostico();
}

void CApuesta::InsertarAlloc(const CColumna &s) 
{
	cols=(CColumna *)realloc(cols,sizeof(CColumna)*(ncols+1));
//	s.valor=s.Valorar(pronostico);
	cols[ncols]=s;
	ncols++;
}

bool CApuesta::Replace(const CColumna &s, int l) 
{
	if (ncols<=l)
		return false;
	cols[l]=s;
	return true;
}

float CApuesta::getVariantesPromedio()
{
	float f=0;
	for (int i=0;i<ncols;i++)
	{
		f+= (cols[i].Variantes());
	}
	return f/ncols;

}


void CApuesta::Distancias(int distancias[15])
{
	int i, hit;
	for (i=0;i<=14;i++)
		distancias[i]=0;
	for (i=0;i<(ncols-1);i++)
	{
		for (int j=i+1;j<ncols;j++)
		{
			hit=cols[i].Match(cols[j]);
			distancias[hit]++;
		}
	}
}
/*
int Criterio(CColumna &s1, CColumna &s2)
{
	if (s1.m_valor>s2.m_valor) return 1;
	if (s2.m_valor>s1.m_valor) return -1;
	return 0;
}*/

int iExpectedSteps;
unsigned long iCuentaSteps;

int QCriterio(const void *p1,const void *p2)
{
	CColumna s1=*((CColumna *)p1);
	CColumna s2=*((CColumna *)p2);
	iCuentaSteps++;
	if (((++iCuentaSteps)%10000)==0)
		::SendMessage(AfxGetMainWnd()->GetSafeHwnd(),MSGQ_PROGRESS,1000*(iCuentaSteps)/iExpectedSteps,0);
//	if (s1.m_valor>s2.m_valor) return -1;
//	if (s2.m_valor>s1.m_valor) return 1;
	if (s1.m_fProb>s2.m_fProb) return -1;
	if (s2.m_fProb>s1.m_fProb) return 1;

	return 0;
}

int QCriterioRent(const void *p1,const void *p2)
{
	CColumna s1=*((CColumna *)p1);
	CColumna s2=*((CColumna *)p2);
	iCuentaSteps++;
	float f1=s1.Rentabilidad(CApuesta::pronostico,CApuesta::pronosticocateto);
	float f2=s2.Rentabilidad(CApuesta::pronostico,CApuesta::pronosticocateto);
	//	if ((++iCuentaSteps)%10000)
	//		::SendMessage(AfxGetMainWnd()->GetSafeHwnd(),MSGQ_PROGRESS,100*(iCuentaSteps)/iExpectedSteps,0);
	if (f1>f2) return -1;
	if (f2>f1) return 1;
	return 0;
}

static CColumna g_ganadora;

int QCriterioAciertos(const void *p1,const void *p2)
{
	CColumna s1=*((CColumna *)p1);
	CColumna s2=*((CColumna *)p2);
	iCuentaSteps++;
	//	if ((++iCuentaSteps)%10000)
	//		::SendMessage(AfxGetMainWnd()->GetSafeHwnd(),MSGQ_PROGRESS,100*(iCuentaSteps)/iExpectedSteps,0);
	int v1=s1.Match(g_ganadora);
	int v2=s2.Match(g_ganadora);
	if (v1>v2) return -1;
	if (v2>v1) return 1;
	return 0;
}

void CApuesta::Ordenar()
{
	iCuentaSteps=0;
	iExpectedSteps=10*ncols*(float)log((float)ncols);
	qsort(cols,ncols,sizeof(CColumna),QCriterio);
//	CString s; s.Format("%lu",iCuentaSteps);AfxMessageBox(s);
	::SendMessage(AfxGetMainWnd()->GetSafeHwnd(),MSGQ_PROGRESS,0,0);
}

void CApuesta::OrdenarPorAciertos(CColumna gana)
{
	g_ganadora=gana;
	iCuentaSteps=0;
	iExpectedSteps=10*ncols*(float)log((float)ncols);
	qsort(cols,ncols,sizeof(CColumna),QCriterioAciertos);
	CString s; s.Format("%lu",iCuentaSteps);
	AfxMessageBox(s);
	::SendMessage(AfxGetMainWnd()->GetSafeHwnd(),MSGQ_PROGRESS,0,0);
}

void CApuesta::OrdenarPorRent()
{
	iCuentaSteps=0;
	iExpectedSteps=10*ncols*(float)log((float)ncols);
	qsort(cols,ncols,sizeof(CColumna),QCriterioRent);
//	CString s; s.Format("%lu",iCuentaSteps);AfxMessageBox(s);
	::SendMessage(AfxGetMainWnd()->GetSafeHwnd(),MSGQ_PROGRESS,0,0);
}

bool CApuesta::Remove(int i)
{
	if (i<0 || i>=ncols)
		return false;
	memcpy((void *)&cols[i],(void *)&cols[i+1],(ncols-1-i)*sizeof(CColumna));
	ncols--;
	cols=(CColumna *)realloc(cols,sizeof(CColumna)*(ncols));
	return true;
}


void CApuesta::Filtrar(int(*filtro)(CColumna,void *),void *dato)
{
	int i;
	if (!ncols) return;
	int tam=ncols;
	ncols=0;
	for (i=0;i<tam;i++)
	{
		if ((i%1000)==0)
			::SendMessage(AfxGetMainWnd()->GetSafeHwnd(),MSGQ_PROGRESS,100*i/tam,0);
		if (filtro(cols[i],dato))
		{
			Replace(cols[i],ncols++);
		}
	}
	::SendMessage(AfxGetMainWnd()->GetSafeHwnd(),MSGQ_PROGRESS,0,0);
	return;
}

CColumna *CApuesta::getBestNext(CApuesta *tmp, int dist)
{
	CColumna *c=tmp->getBestUnflagged();
	if (c)
	{
		int flageados=tmp->FlagAround(*c,dist);
//		totalflag+=flageados;
	}
	return c;
}

CColumna *CApuesta::getBestUnflagged()
{
	CColumna *max=NULL;
	int val=-9999;
	for (unsigned int i=0;i<ncols;i++)
	{
		if (cols[i].getFlag())
			continue;
		if ((i%10000)==0)
			::SendMessage(AfxGetMainWnd()->GetSafeHwnd(),MSGQ_PROGRESS,100*i/ncols,0);
		if (cols[i].m_fProb > val)
		{
			max=&cols[i];
			val=max->m_fProb;
		}
	}
	::SendMessage(AfxGetMainWnd()->GetSafeHwnd(),MSGQ_PROGRESS,0,0);
	return max;
}

int CApuesta::FlagAround(CColumna c, int dist)
{
	int flageados=0;
	for (unsigned int i=0;i<ncols;i++)
	{
		if (cols[i].getFlag())
			continue;
		if ((i%10000)==0)
			::SendMessage(AfxGetMainWnd()->GetSafeHwnd(),MSGQ_PROGRESS,100*i/ncols,0);
		int matches=c.Match(cols[i]);
		if (matches >= (14-dist))
		{
			cols[i].setFlag(1);
			flageados++;
		}
	}
	::SendMessage(AfxGetMainWnd()->GetSafeHwnd(),MSGQ_PROGRESS,0,0);
	return flageados;
}

void CApuesta::removeNeighbours(CColumna c, int dist)
{
	FlagAround(c,dist);
	Filtrar(fFlageadas,NULL);
}

void CApuesta::GenerarTodas()
{
	setSize(0);					//vacio lo primero y elimino la memoria.
	setSize(COMBINACIONES);		//reservo memoria para todo
	unsigned int l;
	for (l=0;l<COMBINACIONES;l++)
	{
		if ((l%10000)==0)
			::SendMessage(AfxGetMainWnd()->GetSafeHwnd(),MSGQ_PROGRESS,100*l/COMBINACIONES,0);
		CColumna s(l);
		s.m_fProb=s.Probabilidad14(pronostico,false);
		Replace(s,l);
	}
	::SendMessage(AfxGetMainWnd()->GetSafeHwnd(),MSGQ_PROGRESS,0,0);
}

int CApuesta::getMinValue()
{
	int minimo=1000;
	for (int i=0;i<ncols;i++)
	{
		if (cols[i].m_fProb<minimo)
			minimo=cols[i].m_fProb;
	}
	return minimo;
}

int CApuesta::getMaxValue()
{
	int maximo=-1000;
	for (int i=0;i<ncols;i++)
	{
		if (cols[i].m_fProb>maximo)
			maximo=cols[i].m_fProb;
	}
	return maximo;
}
/*
vector<int> CApuesta::getHistograma(int bins)
{
	vector<int> vFreq;
	int minimo=getMinValue();
	int maximo=getMaxValue();
	int intervalo=(maximo - minimo)/bins;
	intervalo = intervalo ? intervalo : 1;
	for (int i=minimo;i<maximo;i+=intervalo)
		vFreq.push_back(0);
	for (i=0;i<ncols;i++)
	{
		int aux=cols[i].m_valor-minimo;
		aux=aux/intervalo;
		vFreq[aux]++;
	}
	return vFreq;
}
*/


void CApuesta::setSize(int s)
{	
	ncols=s;
	cols=(CColumna *)realloc(cols,sizeof(CColumna)*(ncols+1));
}


int CApuesta::ContarSignoPorCasilla(signo s, int castilla)
{
	int conta=0;
	for (unsigned int i=0;i<ncols;i++)
	{
		if (cols[i][castilla]==s)
			conta++;
	}
	return conta;

}

float CApuesta::getProb14()
{
	float f=0;
	for (int i=0;i<ncols;i++)
	{
		f += cols[i].Probabilidad14(CApuesta::pronostico,false);
	}
	return f;
}



float CApuesta::getProb14Media()
{
	float f=0;
	for (int i=0;i<ncols;i++)
	{
		f+=cols[i].m_fProb;
	}
	f/=ncols;
	return f/10;
}

float CApuesta::getRentabilMedia()
{
	if (ncols==0) return -1;
	float f=0;
	for (int i=0;i<ncols;i++)
	{
		f+=cols[i].Rentabilidad(CApuesta::pronostico,CApuesta::pronosticocateto);
	}
	f/=ncols;
	return f;
}


int fDistancia(CColumna col,void *dato)
{
	pair<CApuesta *, int> *fdist =(pair<CApuesta *, int> *)dato;
	bool afor=fdist->first->FastMinDist(col,fdist->second);
	if (!afor)
		return 1;
	return 0;
}

int fCeros(CColumna col,void *nada)
{
	for (int j=0;j<14;j++)
	{
		if ((col[j]==0) && (CApuesta::pronostico[j].p1==0))
			return 0;
		if ((col[j]==1) && (CApuesta::pronostico[j].px==0))
			return 0;
		if ((col[j]==2) && (CApuesta::pronostico[j].p2==0))
			return 0;
	}
	return 1;
}

int fBajas(CColumna col,void * v)
{
	return (col.m_fProb>*((float *)v));//si es un 1 es que se queda
}

int fAltas(CColumna col,void *v)
{
	return (col.m_fProb<(int)v);
}

int fRentabilidad(CColumna col,void * v)
{
	double d=col.Rentabilidad(CApuesta::pronostico,CApuesta::pronosticocateto);
	int id=(int)(100*d);
	return (id> (int)v);//si es un 1 es que se queda
}
int fFlageadas(CColumna col,void * f)
{
	return (col.getFlag()==0);
}

void CPremios::Estimar(CPronostico pronosticocatet[14], CColumna ganadora, int iRecaudac)
{
	int totcols=iRecaudac*2;

	// LA DE 14
	m_iAcertantes14=totcols*pow((float)10,(float)ganadora.Valorar(pronosticocatet)/10);

	// LAS DE 13
	vector<CColumna> vc=ganadora.getVecinos(1);
	float probfinal=0;
	for (int i=0;i<vc.size();i++) {probfinal = probfinal + pow((float)10,(float)vc[i].Valorar(pronosticocatet)/10);}
//	probfinal=(float)log(probfinal) / (float)log((float)10);
	m_iAcertantes13=probfinal*totcols;

	// LAS DE 12
	vc=ganadora.getVecinos(2);
	probfinal=0;
	for (int i=0;i<vc.size();i++) {probfinal = probfinal + pow((float)10,(float)vc[i].Valorar(pronosticocatet)/10);}
//	probfinal=(float)log(probfinal) / (float)log((float)10);
	m_iAcertantes12=probfinal*totcols;

	// LAS DE 11
	vc=ganadora.getVecinos(3);
	probfinal=0;
	for (int i=0;i<vc.size();i++) {probfinal = probfinal + pow((float)10,(float)vc[i].Valorar(pronosticocatet)/10);}
//	probfinal=(float)log(probfinal) / (float)log((float)10);
	m_iAcertantes11=probfinal*totcols;

	// LAS DE 10
	vc=ganadora.getVecinos(4);
	probfinal=0;
	for (int i=0;i<vc.size();i++) {probfinal = probfinal + pow((float)10,(float)vc[i].Valorar(pronosticocatet)/10);}
//	probfinal=(float)log(probfinal) / (float)log((float)10);
	m_iAcertantes10=probfinal*totcols;
}


int CApuesta::getPosition(CColumna c)
{
	for (int i=0;i<ncols;i++)
	{
		if (cols[i]==c)
			return i;
	}
	return -1;
}
