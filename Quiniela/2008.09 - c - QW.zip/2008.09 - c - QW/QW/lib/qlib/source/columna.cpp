#include "columna.h"
#include "conf.h"
#include "qutil.h"
#include <stdio.h>
#include <ctype.h>
#include <iostream>
#include <vector>
#ifndef NOWIN
#include <afxwin.h>
#endif

using namespace std;


CColumna::CColumna()
{
	m_fProb=0;
	m_joker=0;
	m_fRent=0;

	for (int i=0;i<14;i++)
		var(i,BLANCO);
//	m_fProb = getProbabilidadReal(CApuesta::pronostico);m_fFreq = getProbabilidadApostada(CApuesta::pronosticocateto);
//	m_fPremioEsperado[4]=0;m_fPremioEsperado[3]=0;m_fPremioEsperado[2]=0;m_fPremioEsperado[1]=0;m_fPremioEsperado[0]=0;

}

CColumna::CColumna(long l) 
{
	DeEntero(l);
	m_fProb=0;
	m_joker=0;
	m_fRent=0;
//	m_fPremioEsperado[4]=0;m_fPremioEsperado[3]=0;m_fPremioEsperado[2]=0;m_fPremioEsperado[1]=0;m_fPremioEsperado[0]=0;
//	m_fProb = getProbabilidadReal(CApuesta::pronostico);m_fFreq = getProbabilidadApostada(CApuesta::pronosticocateto);
}

CColumna::CColumna(string sCol)
{
	if (sCol.empty()) return;
	signo lista[16];
	sprintf(lista,"%s",sCol.c_str());
	m_fProb=0;
	m_joker=0;
	m_fRent=0;

	for (int i=0;i<14;i++)
	{
		if (lista[i]=='1' || lista[i]==UNO) var(i,UNO);
		else if (lista[i]=='2'|| lista[i]==DOS) var(i,DOS);
		else if ((lista[i]=='X')||(lista[i]=='x')|| lista[i]==EQUIS) var(i,EQUIS);
		else var(i,BLANCO);
	}
//	m_fProb = getProbabilidadReal(CApuesta::pronostico);m_fFreq = getProbabilidadApostada(CApuesta::pronosticocateto);
//	m_fPremioEsperado[4]=0;m_fPremioEsperado[3]=0;m_fPremioEsperado[2]=0;m_fPremioEsperado[1]=0;m_fPremioEsperado[0]=0;

}


CColumna::CColumna(signo lista[14])
{
	m_fProb=0;
	m_joker=0;
	m_fRent=0;

	for (int i=0;i<14;i++)
	{
		if (lista[i]=='1' || lista[i]==UNO) var(i,UNO);
		else if (lista[i]=='2'|| lista[i]==DOS) var(i,DOS);
		else if ((lista[i]=='X')||(lista[i]=='x')|| lista[i]==EQUIS) var(i,EQUIS);
		else var(i,BLANCO);
	}
//	m_fProb = getProbabilidadReal(CApuesta::pronostico);m_fFreq = getProbabilidadApostada(CApuesta::pronosticocateto);
//	m_fPremioEsperado[4]=0;m_fPremioEsperado[3]=0;m_fPremioEsperado[2]=0;m_fPremioEsperado[1]=0;m_fPremioEsperado[0]=0;

}



double CColumna::Rentabilidad(CPronostico pronostico[14],CPronostico pronosticocateto[14])
{
	double esperanza=1;
	for (int i=0;i<14;i++)
	{
		double a3=(double)pronosticocateto[i].p2;
		double b3=(double)pronostico[i].p2;
		double a2=(double)pronosticocateto[i].px;
		double b2=(double)pronostico[i].px;
		double a1=(double)pronosticocateto[i].p1;
		double b1=(double)pronostico[i].p1;

		if (var(i)==UNO) esperanza *= b1/a1;
		if (var(i)==EQUIS) esperanza *= b2/a2;
		if (var(i)==DOS) esperanza *= b3/a3;
	}
	esperanza *= 0.55;
	return esperanza;
}

void CColumna::DeEntero(long l)
{
	int i;
	for (i=13;i>=0;i--)
	{
		long n=potencias3[i];
		long div=l/n;
		l=l%n;
		var(i,div);
	}
	return;
}

void NormalizarPronostico(CPronostico a[14], CPronostico ap[14])
{
	for (int i=0;i<14;i++)
	{
		int total = a[i].p1 + a[i].px + a[i].p2;
		if (total!=0)
		{
			ap[i].p1=100*a[i].p1/total;
			ap[i].px=100*a[i].px/total;
			ap[i].p2=100*a[i].p2/total;
		}
		else 
		{
			ap[i].p1=33;ap[i].px=33;ap[i].p2=33;
		}
	}
	return;
}

void CColumna::Random(CPronostico a[14])
{
	CPronostico ap[14];
	NormalizarPronostico(a,ap);
	for (int i=0;i<14;i++)
	{
		var(i,SignoAleatorio(ap[i]));
	}
//	m_valor=Valorar(a);
	m_fProb=(float)Probabilidad14(a,false);

}

int CColumna::Match(const CColumna s2) const
{
	int cont=0;
	for (int i=0;i<14;i++)
		if (var(i)==s2[i]) 
			cont++;
	return cont;
}
string CColumna::getString() const
{
	string s="";
	for (int i=0;i<14;i++)
	{
		if (var(i)==0) s+='1';
		else if (var(i)==1) s+='X';
		else if (var(i)==2) s+='2';
		else s+='?';
	}
	return s;
}
istream &operator>>(istream &is,CColumna &sol)
{
	char c;
	if (!is.good())
		return is;
	for (int i=0;i<14;i++)
	{
		if (is.eof())
			return is;
		is >> c;
		if (is.eof())
			return is;
		if (c=='1') sol.var(i,UNO);
		else if (c=='X') sol.var(i,EQUIS);
		else if (c=='x') sol.var(i,EQUIS);
		else if (c=='2') sol.var(i,DOS);
		else sol.var(i,BLANCO);
	}
	int q=is.peek();
	return is;
}
int CColumna::Unos() const
{
	int conta=0;
	for (int i=0;i<14;i++)
		if (var(i)==UNO) 
			conta++;
	return conta;
}

int CColumna::Variantes() const
{
	int conta=0;
	for (int i=0;i<14;i++)
		if (var(i)!=UNO) 
			conta++;
	return conta;
}

int CColumna::Equis() const
{
	int conta=0;
	for (int i=0;i<14;i++)
		if (var(i)==EQUIS) 
			conta++;
	return conta;
}

int CColumna::Doses() const
{
	int conta=0;
	for (int i=0;i<14;i++)
		if (var(i)==DOS) 
			conta++;
	return conta;
}

//un numero del 0 al 100
//tengo que mirar el valor minimo, el maximo, 
//y asignar 0 y 100 a todo eso, para que sea un valor de 0 a 100
long CColumna::Valorar(CPronostico a[14]) const
{
	float fpuntos=Probabilidad14(a)*10;
	long puntos=(long)fpuntos; 
	return (long)puntos;
}

void CColumna::Mutar(CPronostico a[14])
{
	int i,previo;
	do
	{
		i=14*rand()/RAND_MAX;
		previo=var(i);
		var(i,SignoAleatorio(a[i]));
	}
	while(previo==var(i));
}

char getCharFromSigno(signo c)
{
	if (c==UNO)
		return '1';
	else if (c==EQUIS)
		return 'X';
	else if (c==DOS)
		return '2';
	else return '.';

}

float CColumna::Probabilidad14(CPronostico pro[14], bool bLogaritmico) const
{
	long double pac=1;

	for (int i=0;i<14;i++)
	{
		int suma=pro[i].p1 + pro[i].px + pro[i].p2;
		float p1=(float)pro[i].p1 / suma;
		float p2=(float)pro[i].px / suma;
		float p3=(float)pro[i].p2 / suma;
		if (var(i)==0) pac=pac*p1;
		if (var(i)==1) pac=pac*p2;
		if (var(i)==2) pac=pac*p3;
	}
	return (bLogaritmico) ? ((float)log(pac) / (float)log((float)10)) : (float)pac;
}

signo Rotar(signo s)
{
	if (s==UNO) return EQUIS;
	if (s==EQUIS) return DOS;
	return UNO;
}

vector<CColumna> CColumna::getVecinos(int iDistancia, int iFrom)
{
	vector<CColumna> vCols;
	if (iDistancia==0)
	{
		vCols.push_back(*this);
		return vCols;
	}

	for (int i=iFrom;i<14;i++)
	{
		CColumna c=*this;
		c.var(i,Rotar(c.var(i)));
		if (iDistancia==1)
			vCols.push_back(c);
		if (iDistancia>1)
		{
			int iDist=iDistancia-1;
			vector<CColumna> vColsTmp=c.getVecinos(iDist,i+1);
			for (unsigned int k=0;k<vColsTmp.size();k++)
				vCols.push_back(vColsTmp[k]);
		}
		c.var(i,Rotar(c.var(i)));
		if (iDistancia==1)
			vCols.push_back(c);
		if (iDistancia>1)
		{
			int iDist=iDistancia-1;
			vector<CColumna> vColsTmp=c.getVecinos(iDist,i+1);
			for (unsigned int k=0;k<vColsTmp.size();k++)
				vCols.push_back(vColsTmp[k]);
		}

	}
	return vCols;
}

double CColumna::getProbabilidadApostada(CPronostico pronosticocateto[14])
{
	double prob=1;
	for (int i=0;i<14;i++)
	{
		if (var(i) == UNO) prob*=pronosticocateto[i].p1;
		else if (var(i) == EQUIS) prob*=pronosticocateto[i].px;
		else if (var(i) == DOS) prob*=pronosticocateto[i].p2;
		else return -1;
		prob*= 1E-2;
	}
	return prob;
}

double CColumna::getProbabilidadReal(CPronostico pronostico[14])
{
	double prob=1;
	for (int i=0;i<14;i++)
	{
		if (var(i) == UNO) prob*=pronostico[i].p1;
		else if (var(i) == EQUIS) prob*=pronostico[i].px;
		else if (var(i) == DOS) prob*=pronostico[i].p2;
		else return -1;
	}
	prob *= 1E-28;
	return prob;
}

double CColumna::getPremioEsperado(int nivel)
{
//	if (m_fPremioEsperado[nivel]!=0) return m_fPremioEsperado[nivel];

	vector<CColumna> vecvec = getVecinos(nivel);
	double reparto=0;
	if (nivel==0) reparto = 0.22;
	if (nivel==1) reparto = 0.08;
	if (nivel==2) reparto = 0.08;
	if (nivel==3) reparto = 0.08;
	if (nivel==4) reparto = 0.09;

	double suma=0;
	for (int j=0;j<vecvec.size();j++)
	{
		CColumna vecvecina = vecvec[j];
		double f= vecvecina.getProbabilidadApostada(CApuesta::pronosticocateto);
		suma += f;
	}
	double q = reparto / suma;

//	m_fPremioEsperado[nivel]=q;
	return q;
}

double CColumna::getRentabilidadPorNivel(int nivel)
{
	vector<CColumna> vecinos = getVecinos(nivel);
	double rentatotal=0;
	for (int i=0;i<vecinos.size();i++)
	{
		CColumna vecina = vecinos[i];
		double qesperado=vecina.getPremioEsperado(nivel);
		double preal = vecina.getProbabilidadReal(CApuesta::pronostico);
		double rentaparcial = qesperado * preal;
		rentatotal += rentaparcial;
	}
	return rentatotal;
}

float CColumna::getRentabilidad(bool bDoNotCalculate)
{
	if (!bDoNotCalculate)
	{
		double renta0= getRentabilidadPorNivel(0);
		double renta1= getRentabilidadPorNivel(1);
		double renta2= getRentabilidadPorNivel(2);
		double renta3= getRentabilidadPorNivel(3);
		double renta4= getRentabilidadPorNivel(4);
		double rentatotal=renta0+renta1+renta2+renta3+renta4;
		m_fRent=rentatotal;
	}
	return m_fRent;
}

