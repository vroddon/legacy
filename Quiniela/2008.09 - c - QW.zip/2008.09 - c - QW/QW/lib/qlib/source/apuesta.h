#pragma once
#define COMBINACIONES 4782969
#include <sstream>
#include <iostream>
#include <fstream>
#include <math.h>
#include <time.h>
#include <vector>
using namespace std;
#pragma warning (disable:4786)

#include "columna.h"
#include "pronostico.h"

#define VERSION97

class CPremios
{
public:
	CPremios();

	void Estimar(CPronostico pronosticocatet[15], CColumna colgana, int iRecaudac);

	/**
	* Establece todos los premios, acertantes y recaudacion a 0
	*/
	void ResetPremios();


	int iRecaudacion;
	int iPremio15;		//premios dados en euros
	int iPremio14;
	int iPremio13;
	int iPremio12;
	int iPremio11;
	int iPremio10;
	int m_iAcertantes15;
	int m_iAcertantes14;
	int m_iAcertantes13;
	int m_iAcertantes12;
	int m_iAcertantes11;
	int m_iAcertantes10;
	int m_iPrecio; //precio de la apuesta dado en centimos.
};


class CApuesta
{
public:
	/**
	* Creates the apuesta with _ncols columns. 
	* By default, it allocates memory for all of them
	*/
	CApuesta(int _ncols=COMBINACIONES); 
	CApuesta(const CApuesta &);

	~CApuesta();

	/** 
	* Quita la columna i-esima
	* Rearranges the memory (i.e. the capacity of the apuesta is --)
	* return False if error
	*/
	bool Remove(int i);

	/**
	* Inserta una columna en la apuesta, en la posicion i-esima (que debe ser ya existente).
	* 
	*/
	bool Replace(const CColumna &s, int i);

	/**
	* Inserta una columna en la apuesta reservando una posicion de memoria extra
	* La columna insertada se inserta al final
	* La columna no es valorada
	*/
	void InsertarAlloc(const CColumna &s);


	void ResetPronostico(CPronostico p[14]);

	/**
	* Genera toda las columnas posibles.
	* Elimina cualquier columna previa.
	* Reserva la memoria naturalmente que necesita
	*/
	void GenerarTodas();

	/**
	* Devuelve el numero de aciertos de una apuesta dada la solucion
	* s es la soluci�n
	* pleno15 es el signo del pleno al quince
	* premio es la estructura que se llena
	*/
	int Escrutar(CColumna s,signo pleno15, CPremios premios);

	/**
	* 	true si la apuesta contiene alguna columna a distancia de s menor o igual que la dada
	*/
	bool FastMinDist(CColumna s,int criterio=0);

	/**
	* Devuelve para la presente apuesta, el n�mero de columnas que quedan cubiertas.
	* Por ejemplo, para una apuesta, catorce=1, trece=28 etc.
	*/
	int Probabilidades(int *catorce, int *trece, int *doce, int *once, int *diez,int criterio);

	/**
	* Deja en el vector distancias (debe tener tama�o 15)
	* el n�mero de columnas a distancia 0,1,...,14
	* distancias[0] tiene el n� de columnas a distancias 0 etc.
	*/
	void Distancias(int distancias[]);

	/**
	* Para la columna s, dice la minima distancia a que tiene un vecino. 
	* Dos columnas difiriendo en un signo, devolver�a un 1.
	*/
	int getMinDist(CColumna s);

	/**
	* Para la columna k-esima, dice la minima distancia a que tiene sus vecinos en la apuesta. 
	* Dos columnas difiriendo en un signo, devolver�a un 1.
	*/
	int getMinDist(int k);

	/**
	* filtro es una funcion que debe devolver 0 si la columna no pasa el filtro
	* o devolver 1 si la columna pasa el corte.
	*  Adicionalmente hay un parametro libre.
	*/
	void Filtrar(int(*filtro)(CColumna,void *),void *dato);

	/**
	* Cuenta el numero de signos que ocurren en la apuesta para la casilla casilla.
	*/
	int ContarSignoPorCasilla(signo s, int casilla);

	/**
	* Returns the maximum value in the apuesta
	*/
	int getMaxValue();

	/**
	* Returns the minimum value in the apuesta
	*/
	int getMinValue();

	/**
	* Returns the average variantes
	*/
	float getVariantesPromedio();

	/**
	* Returns the average value of the cols in dB
	*/
	float getProb14Media();

	/**
	* Returns the total value of the cols probability 
	*/
	float getProb14();

	/**
	* Returns the average value of rentability
	*/
	float getRentabilMedia();

	/**
	* Returns a histogram of bins bins which the values of apuesta
	*/
//	vector<int> getHistograma(int bins);

	/**
	* Ordena las columnas por orden de valoracion
	* Algoritmo qsort, no da informaci�n de progreso
	*/
	void Ordenar();

	/**
	* Ordena las columnas por orden de aciertos
	* Algoritmo qsort, no da informaci�n de progreso
	*/
	void OrdenarPorAciertos(CColumna gana);

	/**
	* Ordena las columnas atendiendo a su rentabilidad.
	*/
	void OrdenarPorRent();

	/**
	* Accede a la columna i-esima
	*/
	CColumna &operator[](int i){return cols[i];}

	friend ostream &operator<<(ostream &o,CApuesta &a);
	friend istream &operator>>(istream &is,CApuesta &a);

	/**
	* Returns the number of columns
	*/
	int getSize() const {return ncols;}

	/**
	* Allocs memory for a given number of columns
	*/
	void setSize(int s);

	CColumna *getBestUnflagged();
	CColumna *getBestNext(CApuesta *tmp,int dist);

	/**
	* Flags around all the columns at a distance <= dist
	*/
	int FlagAround(CColumna c, int dist);

	/**
	* Removes columns at distance i.
	*/
	void removeNeighbours(CColumna c, int dist);


	/**
	* Returns the position of the c column in the apuesta
	* -1 si no esta
	* 0 para la primera posicion etc.
	*/
	int getPosition(CColumna c);

	int *mark;

	/**
	* Columnas de la apueta. Es un puntero, allocado din�micamente seg�n la necesidad.
	*/
	CColumna *cols;
	static CPronostico pronostico[14];
	static CPronostico pronosticocateto[14];

	int m_iAciertos15, m_iAciertos14,m_iAciertos13,m_iAciertos12,m_iAciertos11,m_iAciertos10;
	int m_iPremioTotal;
private:
	int ncols;
};

int fDistancia(CColumna col,void *dato);
int fCeros(CColumna col,void *nada);
int fAltas(CColumna col,void * v);
int fBajas(CColumna col,void * v);
int fRentabilidad(CColumna col,void * v);

