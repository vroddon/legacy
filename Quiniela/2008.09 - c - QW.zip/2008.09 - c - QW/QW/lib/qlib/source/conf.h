#pragma once


#define MSGQ_PROGRESS WM_USER + 1
#define MSGQ_MSG WM_USER + 2


#define UNO 0
#define EQUIS 1
#define DOS 2
#define BLANCO 3

