#pragma once

//representa la probabilidad de un partido
class CPronostico
{
public:
	CPronostico(int _p1=34,int _px=33,int _p2=33) : p1(_p1), p2(_p2), px(_px){}

	bool Redondear(float f1, float fx, float f2);
	bool FromRatio(float f1, float fx, float f2);
	
	int p1;
	int px;
	int p2;
};


