#pragma once
#include "apuesta.h"
#include "pronostico.h"
#include <string>
#include <vector>
#pragma warning (disable:4786)

using namespace std;

bool LeerPronostico(CPronostico pronostico[14], char *nombre="pronostico.txt");
bool LeerPartidos(vector<string> &partidos, char *nombre="partidos.txt");
/*
* Al leer una apuesta se hace una valoracion tambien.
*/
bool LeerApuesta(class CApuesta *a, string archivo="apuesta.txt");
bool LeerSolucion(class CColumna *c, string archivo="solucion.txt");

signo SignoAleatorio(CPronostico p);

bool GuardarPartidos(vector<string> partidos, char *nombre="partidos.txt");
bool GuardarPronostico(CPronostico pronostico[14], char *nombre="pronostico.txt");
bool GuardarApuesta(class CApuesta *a, string archivo="apuesta.txt");
bool GuardarSolucion(class CColumna *c, string archivo="solucion.txt");

