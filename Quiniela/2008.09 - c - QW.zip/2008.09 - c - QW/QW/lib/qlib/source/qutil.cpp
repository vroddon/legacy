#include "qutil.h"
#include "apuesta.h"
#include "pronostico.h"
#include "conf.h"
#include <sstream>
#include <iostream>
#include <fstream>

#ifndef NOWIN
	#include <afxwin.h>
#endif

using namespace std;

bool LeerPronostico(CPronostico pronostico[14], char *nombre)
{
	ifstream fprono(nombre);
	for (int i=0;i<14;i++)
	{
		fprono >> pronostico[i].p1;
		fprono >> pronostico[i].px;
		fprono >> pronostico[i].p2;
		int total=pronostico[i].p1+pronostico[i].px+pronostico[i].p2;
		pronostico[i].p1=int((float)pronostico[i].p1*float(100/(float)total));
		pronostico[i].px=int((float)pronostico[i].px*float(100/(float)total));
		pronostico[i].p2=int((float)pronostico[i].p2*float(100/(float)total));
	}
	return true;
}


bool GuardarPronostico(CPronostico pronostico[14],char *nombre)
{
	ofstream fprono(nombre);
	for (int i=0;i<14;i++)
	{
		fprono << pronostico[i].p1 << "\t";
		fprono << pronostico[i].px << "\t";
		fprono << pronostico[i].p2 << "\n";
	}
	return true;
}



bool LeerPartidos(vector<string> &partidos, char *nombre)
{
	int i;
	partidos.empty();
	ifstream fprono(nombre);
	if (fprono.eof())
		return false;
	char c[1024];
	partidos.clear();
	for (i=0;i<14;i++)
	{
		fprono.getline(c,1024);
		partidos.push_back(c);
	}
	fprono.close();
	return true;
}
bool GuardarPartidos(vector<string> partidos, char *nombre)
{
	ofstream fprono(nombre);
	if (!fprono.good())
		return false;
	if (partidos.size()<14)
		return false;
	for (int i=0;i<14;i++)
	{
		fprono << partidos[i];
		fprono << "\n";
	}
	return true;

}


signo SignoAleatorio(CPronostico p)
{
	int alea=100*rand()/RAND_MAX;
	if (alea<p.p1) return 0;
	if (alea<(p.p1+p.px)) return 1;
	return 2;
}

bool LeerApuesta(class CApuesta *a, string archivo)
{
	if (!a) return false;
	ifstream ifs(archivo.c_str());
	if (!ifs.is_open())
		return false;
	if (ifs.eof())
		return false;
	ifs >> *a;
	for (int i=0;i<a->getSize();i++)
	{
		if (i%100==0)
		{
			::SendMessage(AfxGetMainWnd()->GetSafeHwnd(),MSGQ_PROGRESS,100*i/a->getSize(),0);
		}
//		a->cols[i].m_valor=a->cols[i].Valorar(p);
		a->cols[i].m_fProb=a->cols[i].Probabilidad14(CApuesta::pronostico,false);
	}
	::SendMessage(AfxGetMainWnd()->GetSafeHwnd(),MSGQ_PROGRESS,0,0);

	return true;	
}

bool GuardarApuesta(class CApuesta *a, string archivo)
{
	ofstream ofs(archivo.c_str());
	ofs << *a;
	return true;
}
bool GuardarSolucion(class CColumna *c, string archivo)
{
	ofstream ofs(archivo.c_str());
	ofs << *c;
	return true;
}
bool LeerSolucion(class CColumna *c, string archivo)
{
	if (!c) return false;
	ifstream ifs(archivo.c_str());
	if (!ifs.is_open())
		return false;
	if (ifs.eof())
		return false;
	ifs >> *c;
	return true;
}
