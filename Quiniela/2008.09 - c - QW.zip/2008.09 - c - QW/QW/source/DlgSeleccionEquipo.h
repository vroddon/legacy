#pragma once

#include "afxwin.h"
#include "QWManager.h"
#include <string>


// Cuadro de di�logo de CDlgSeleccionEquipo
using namespace std;

class CDlgSeleccionEquipo : public CDialog
{
	DECLARE_DYNAMIC(CDlgSeleccionEquipo)

public:
	CDlgSeleccionEquipo(CWnd* pParent = NULL, CQWManager *manager=NULL);   // Constructor est�ndar
	virtual ~CDlgSeleccionEquipo();
	string m_sEquipoL, m_sEquipoV;

// Datos del cuadro de di�logo
	enum { IDD = IDD_SELECCIONEQUIPO };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // Compatibilidad con DDX o DDV
	virtual BOOL OnInitDialog();

	DECLARE_MESSAGE_MAP()
public:
	CQWManager *m_manager;
	afx_msg void OnBnClickedOk();
	CListBox m_listEquipos;
	afx_msg void OnBnClickedOk2();
	CListBox m_listEquipos2;
	afx_msg void OnBnClickedOk3();
};
