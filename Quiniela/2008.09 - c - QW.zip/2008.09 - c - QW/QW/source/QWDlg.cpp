#include "stdafx.h"

#pragma warning (disable:4786)

#include <math.h>


//QLIB
#include "../lib/qlib/source/conf.h"
#include "../lib/qlib/source/apuesta.h"
#include "../lib/qlib/source/Qutil.h"

//QW
#include "conf.h"
#include "progbar.h"
#include "QW.h"
#include "QWDlg.h"
#include "GetNumberDlg.h"
#include "ColumnasFijasDlg.h"
#include "SaveDBDlg.h"
#include "AboutDlg.h"
#include "qdb.h"
#include "DlgSeleccionEquipo.h"
#include ".\qwdlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#pragma warning (disable:4786)


/////////////////////////////////////////////////////////////////////////////
// CQWDlg dialog

static UINT BASED_CODE indicators[] =
{
	ID_INDICATOR_UNO,
	ID_INDICATOR_DOS
};

CQWDlg::CQWDlg(CWnd* pParent, CQWManager *manager): CDialog(CQWDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CQWDlg)
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32

	m_manager=manager;
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

	m_fontcourier=new CFont();m_fontcourier->CreateFont(16, 0, 0, 0, FW_BOLD , 0, 0, 0, 0, 0, 0, 0, 0, "Courier New" );
	m_fontgorda=new CFont();m_fontgorda->CreateFont(20, 0, 0, 0, FW_BOLD , 0, 0, 0, 0, 0, 0, 0, 0, "Arial" );
	m_status=new CProgStatusBar();
}

CQWDlg::~CQWDlg()
{
	delete m_status;
	delete m_fontgorda;
	delete m_fontcourier;
}

void CQWDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CQWDlg)
	DDX_Control(pDX, IDC_DISTANCIAMIN, m_textDistanciaMin);
	DDX_Control(pDX, IDC_PROB14MEDIA, m_textProb14Media);
	DDX_Control(pDX, IDC_APUESTAVARIANTES, m_textApuestaVariantes);
	DDX_Control(pDX, IDC_FLAG, m_textFlag);
	DDX_Control(pDX, IDC_PREMIOS10, m_textpremios10);
	DDX_Control(pDX, IDC_PREMIOS11, m_textpremios11);
	DDX_Control(pDX, IDC_PREMIOS12, m_textpremios12);
	DDX_Control(pDX, IDC_PREMIOS13, m_textpremios13);
	DDX_Control(pDX, IDC_PREMIOS14, m_textpremios14);
	DDX_Control(pDX, IDC_PROB14, m_textprob14);
	DDX_Control(pDX, IDC_NCOLS, m_textncols);
	DDX_Control(pDX, IDC_NUMBERCOL, m_textnumbercol);
	DDX_Control(pDX, IDC_COLUMNASEL, m_textcolumnasel);
	DDX_GridControl(pDX, IDC_REJA, m_reja);
	//}}AFX_DATA_MAP
	DDX_Control(pDX, IDC_CBTEMPORADA, m_cbTemporada);
	DDX_Control(pDX, IDC_CBJORNADA, m_cbJornada);
	DDX_Control(pDX, IDC_RECAUDACION, m_stRecaudacion);
	DDX_Control(pDX, IDC_PREMI14, m_stPremi14);
	DDX_Control(pDX, IDC_PREMI13, m_stPremi13);
	DDX_Control(pDX, IDC_PREMI12, m_stPremi12);
	DDX_Control(pDX, IDC_PREMI11, m_stPremi11);
	DDX_Control(pDX, IDC_PREMI10, m_stPremi10);
	DDX_Control(pDX, IDC_ACIERTOSSELCOL, m_stAciertosSelCol);
	DDX_Control(pDX, IDC_RENTABILMED, m_stRentabilMed);
	DDX_Control(pDX, IDC_PREMIOTOTAL, m_stPremioTotal);
	DDX_Control(pDX, IDC_PREMI15, m_stPremi15);
	DDX_Control(pDX, IDC_PREMIOS15, m_textPremios15);
	DDX_Control(pDX, IDC_PRONOSMARCA, m_stPronosMarca);
	DDX_Control(pDX, IDC_PRECIOAPUESTA, m_stPrecioApuesta);
	DDX_Control(pDX, IDC_ACER14, m_stAcer14);
	DDX_Control(pDX, IDC_ACER13, m_stAcer13);
	DDX_Control(pDX, IDC_ACER12, m_stAcer12);
	DDX_Control(pDX, IDC_ACER11, m_stAcer11);
	DDX_Control(pDX, IDC_ACER10, m_stAcer10);
	DDX_Control(pDX, IDC_ACER15, m_stAcer15);
	DDX_Control(pDX, IDC_EQUIPOLOCAL, m_stEquipoLocal);
	DDX_Control(pDX, IDC_EQUIPOVISITANTE, m_stEquipoVisitante);
	DDX_Control(pDX, IDC_FILACOMMENTS, m_stFilaComments);
	DDX_Control(pDX, IDC_RENTEXACTA, m_stRentExacta);
}
	//ON_WM_CONTEXTMENU()

BEGIN_MESSAGE_MAP(CQWDlg, CDialog)
	//{{AFX_MSG_MAP(CQWDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_COMMAND(ID_ARCHIVO_GUARDARTODO, OnArchivoGuardartodo)
	ON_COMMAND(ID_ARCHIVO_GUARDARENDB, OnArchivoGuardarendb)
	ON_COMMAND(ID_ARCHIVO_ABRIRAPUESTA32831, OnArchivoAbrirapuestaNUEVO)
	ON_COMMAND(ID_ARCHIVO_SALIR, OnArchivoSalir)

	ON_COMMAND(ID_EDICION_PEGAR, OnEdicionPegar)
	ON_COMMAND(ID_EDICION_ORDENAR, OnEdicionOrdenar)
	ON_COMMAND(ID_EDICION_ORDENARACIERTOS, OnEdicionOrdenaraciertos)
	ON_COMMAND(ID_EDICION_REVALORAR, OnEdicionRevalorar)
	ON_COMMAND(ID_EDICION_ORDENARPORRENT, OnEdiciOrdenarporrent)

	ON_COMMAND(ID_INSERTAR_MASPROBABLE, OnInsertarMasProbable)
	ON_COMMAND(ID_INSERTAR_GENERARTODAS, OnInsertarGenerartodas)
	ON_COMMAND(ID_INSERTAR_INSERTARCOLUMNA, OnInsertarInsertarcolumna)
	ON_COMMAND(ID_INSERTAR_ALEATORIA, OnInsertarAleatoria)
	ON_COMMAND(IDC_INSERTAR1ALEATORIA, OnInsertar1aleatoria)

	ON_COMMAND(ID_ELIMINAR_ELIMINARTODAS, OnEliminarEliminartodas)
	ON_COMMAND(ID_ELIMINAR_MINIMAPROB, OnEliminarMinimaprob)
	ON_COMMAND(ID_ELIMINAR_ELIMINARCOLUMNA, OnEliminarEliminarcolumna)
	ON_COMMAND(ID_ELIMINAR_MINIMARENTABILIDAD, OnEliminarMinimarentabilidad)
	ON_COMMAND(ID_ELIMINAR_QUITARIMPOSIBLES, OnEliminarQuitarimposibles)
	ON_COMMAND(ID_ELIMINAR_REDUCIR_DISTANCIA0, OnEliminarReducirDistancia0)
	ON_COMMAND(ID_ELIMINAR_REDUCIR_DISTANCIA1, OnEliminarReducirDistancia1)
	ON_COMMAND(ID_ELIMINAR_REDUCIR_DISTANCIA2, OnEliminarReducirDistancia2)
	ON_COMMAND(ID_ELIMINAR_REDUCIR_DISTANCIA3, OnEliminarReducirDistancia3)
	ON_COMMAND(ID_ELIMINAR_REDUCIR_DISTANCIA4, OnEliminarReducirDistancia4)
	ON_COMMAND(ID_ELIMINAR_REDUCIR_DISTANCIA5, OnEliminarReducirDistancia5)
	ON_COMMAND(ID_ELIMINAR_REDUCIR_DISTANCIA6, OnEliminarReducirDistancia6)
	ON_COMMAND(ID_ELIMINAR_REDUCIR_DISTANCIA7, OnEliminarReducirDistancia7)

	ON_COMMAND(ID_FILA_REDISTRIBUIR, OnFilaRedistribuir)

	ON_COMMAND(ID_COLUMNA_QUITAR1, OnColumnaQuitar1)
	ON_COMMAND(ID_COLUMNA_QUITAR2, OnColumnaQuitar2)
	ON_COMMAND(ID_COLUMNA_QUITAR3, OnColumnaQuitar3)
	ON_COMMAND(ID_COLUMNA_QUITAR4, OnColumnaQuitar4)
	ON_COMMAND(ID_COLUMNA_QUITAR5, OnColumnaQuitar5)

	ON_COMMAND(ID_ESCRUTINIO_ESCRUTAR, OnEscrutinioEscrutar)
	ON_COMMAND(ID_ANALISIS_HISTOGRAMA, OnAnalisisHistograma)
	ON_COMMAND(ID_ANALISIS_PROBABILIDADES, OnAnalisisProbabilidades)

	ON_COMMAND(ID_AYUDA_ACERCADE, OnAyudaAcercaDe)
	ON_COMMAND(ID_AYUDA_IMPORTAR, OnAyudaImportar)
	ON_COMMAND(ID_AYUDA_JOKER, OnAyudaJoker)
	ON_COMMAND(ID_AYUDA_IMPORTARAPOSTADAS, OnAyudaImportarapostadas)

	ON_NOTIFY(GVN_ENDLABELEDIT, IDC_REJA, OnGridEndEdit)
	ON_NOTIFY(GVN_BEGINLABELEDIT, IDC_REJA, OnGridStartEdit)
	ON_NOTIFY(GVN_SELCHANGED, IDC_REJA, OnGridEndSelChange)
	ON_NOTIFY(NM_RCLICK, IDC_REJA, OnGridRClick)
	//}}AFX_MSG_MAP
	ON_COMMAND(ID_COLUMNMENU_INSERTARCOLS, OnColumnmenuInsertarcols)
	ON_COMMAND(ID_COLUMNA_ELIMINARCOLUMNA, OnColumnaEliminarcolumna)
	ON_CBN_SELCHANGE(IDC_CBJORNADA, OnCbnSelchangeCbjornada)
	ON_CBN_SELCHANGE(IDC_CBTEMPORADA, OnCbnSelchangeCbtemporada)
	ON_BN_CLICKED(IDC_CALCRENTEXACTA, OnBnClickedCalcrentexacta)
	ON_BN_CLICKED(IDC_FIJAREQUIPOLOCAL, OnBnClickedFijarequipolocal)
	ON_COMMAND(ID_ARCHIVO_GUARDARAPUESTA32830, OnArchivoGuardarapuesta32830)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CQWDlg message handlers

BOOL CQWDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	//STATUSBAR
	m_status->Create(this);
	m_status->SetIndicators(indicators,2);
	CRect rect;GetClientRect(&rect);
	m_status->SetPaneInfo(0,ID_INDICATOR_UNO,SBPS_NORMAL,rect.Width()-300);      
	m_status->SetPaneInfo(1,ID_INDICATOR_DOS,SBPS_STRETCH ,0);
	RepositionBars(AFX_IDW_CONTROLBAR_FIRST,AFX_IDW_CONTROLBAR_LAST,ID_INDICATOR_DOS);

	//THE SHEET IS PREPARED
	PrepararReja();

	//FIRST CHECK IN DATABASE!
	InitializeTemporadas();m_cbTemporada.SetCurSel(0);OnCbnSelchangeCbtemporada();

	//REVALORAR
	OnEdicionRevalorar();	 //para normalizar valoraciones discolas

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CQWDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)	{CAboutDlg dlgAbout;dlgAbout.DoModal();}
	else	{CDialog::OnSysCommand(nID, lParam);}
}

void CQWDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting
		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;
		dc.DrawIcon(x, y, m_hIcon);
	}
	else { CDialog::OnPaint(); }
}

HCURSOR CQWDlg::OnQueryDragIcon() { return (HCURSOR) m_hIcon; }


LRESULT CQWDlg::WindowProc(UINT message, WPARAM wParam, LPARAM lParam) 
{
	if(message==MSGQ_PROGRESS)
	{
		m_status->SetPaneText(0," ");m_status->OnProgress(0);m_status->UpdateWindow();
		m_status->OnProgress(wParam);
		if ((char *)wParam==0) m_status->SetPaneText(0,(char *)wParam,1);
		m_status->UpdateWindow();
	}
	if(message==MSGQ_MSG)
	{
		m_status->OnProgress(0);
		m_status->SetPaneText(0,(char *)wParam,1);
		m_status->UpdateWindow();
	}

	return CDialog::WindowProc(message, wParam, lParam);
}

void CQWDlg::OnGridEndEdit(NMHDR *pNotifyStruct, LRESULT* pResult)
{
	NM_GRIDVIEW* pItem = (NM_GRIDVIEW*) pNotifyStruct;
	CString s=m_reja.GetItemText(pItem->iRow,pItem->iColumn);
	*pResult = 0;
	int numcol=pItem->iColumn-12;
	if (numcol>=m_manager->m_apuesta->getSize())
	{
		*pResult=-1;
		return;
	}
	if (pItem->iColumn>11) 
	{
		*pResult=-1;
		if (!s.Compare("2") || !s.Compare("1") || !s.Compare("x") || !s.Compare("X"))
			*pResult = 0;
		if (!s.Compare("x"))
			m_reja.SetItemText(pItem->iRow,pItem->iColumn,"X");
	}
	if (pItem->iColumn>=6 && pItem->iColumn<=11)
	{
		CString s=m_reja.GetItemText(pItem->iRow,pItem->iColumn);
		const char *s2=s;
		int iNum=atoi(s2);
		if (pItem->iColumn==6) CApuesta::pronostico[pItem->iRow-1].p1=iNum;
		if (pItem->iColumn==7) CApuesta::pronostico[pItem->iRow-1].px=iNum;
		if (pItem->iColumn==8) CApuesta::pronostico[pItem->iRow-1].p2=iNum;
		if (pItem->iColumn==9) CApuesta::pronosticocateto[pItem->iRow-1].p1=iNum;
		if (pItem->iColumn==10) CApuesta::pronosticocateto[pItem->iRow-1].px=iNum;
		if (pItem->iColumn==11) CApuesta::pronosticocateto[pItem->iRow-1].p2=iNum;
	}
	if (pItem->iColumn==1)
	{
		ActualizarDatosDeUI();
		LlenarApuesta();
	}
	if (pItem->iColumn>=12)
	{
		signo signos[14];
		for (int j=0;j<14;j++)
		{
			CString s=m_reja.GetItemText(j+1,pItem->iColumn);
			const char *s2=s;
			signos[j]=BLANCO;
			if (s2[0]=='1')
				signos[j]=UNO;
			if (s2[0]=='X')
				signos[j]=EQUIS;
			if (s2[0]=='2')
				signos[j]=DOS;

		}
		CColumna cnueva(signos);
		m_manager->m_apuesta->Replace(cnueva,numcol);
		LlenarApuesta();
	}

}
void CQWDlg::OnGridStartEdit(NMHDR *pNotifyStruct, LRESULT* pResult)
{
	NM_GRIDVIEW* pItem = (NM_GRIDVIEW*) pNotifyStruct;
	if (pItem->iColumn>2 && pItem->iColumn<6)
		*pResult=-1;
	else
		*pResult=0;
	int posicion=pItem->iColumn-12;
	if (posicion>=m_manager->m_apuesta->getSize())
		*pResult=-1;

}
void CQWDlg::OnGridEndSelChange(NMHDR *pNotifyStruct, LRESULT* /*pResult*/)
{
	NM_GRIDVIEW* pItem = (NM_GRIDVIEW*) pNotifyStruct;
	LlenarEstadisticasCol(NULL);

	char a[256];
	int selcol=pItem->iColumn-12;
	int selfila=pItem->iRow-1;
	LlenarEstadisticasFila(selfila);

	if (selcol>=0 && selcol<m_manager->m_apuesta->getSize())
	{
		sprintf(a,"N�m.: %d",selcol);
		m_textnumbercol.SetWindowText(a);
		LlenarEstadisticasCol(&m_manager->m_apuesta->cols[selcol]);
	}
	if (pItem->iColumn==1) // la ganadora
	{
		sprintf(a,"Resultado");
		m_textnumbercol.SetWindowText(a);
		LlenarEstadisticasCol(&m_manager->m_ganadora);
	}
	if (pItem->iColumn>=6 && pItem->iColumn<=8)
	{
		sprintf(a,"Pronostico");
		m_textnumbercol.SetWindowText(a);
	}
}

vector<CColumna *> CQWDlg::getSelCols()
{
	vector<CColumna *> vc;
	CCellRange cr=m_reja.GetSelectedCellRange();	
	for (int c=cr.GetMinCol()-12;c<cr.GetMaxCol()-11;c++)
	{
		if (c>=0 && c<m_manager->m_apuesta->getSize())
			vc.push_back(&m_manager->m_apuesta->cols[cr.GetMinCol()-12]);
	}
	if (cr.GetMinCol()==1)
		vc.push_back(&m_manager->m_ganadora);
	return vc;
}

vector<int> CQWDlg::getSelFilas()
{
	vector<int> vc;
	CCellRange cr=m_reja.GetSelectedCellRange();	
	for (int c=cr.GetMinRow()-1;c<cr.GetMaxRow();c++)
		vc.push_back(c);
	return vc;
}

void CQWDlg::ActualizarDatosDeUI()
{
	CString s;
	int i;

	//Actualizacion de partidos
	m_manager->m_partidos.clear();
	for (i=0;i<14;i++)
	{
		s=m_reja.GetItemText(i+1,2);
		m_manager->m_partidos.push_back(s.GetBuffer(1024));
	}

	//Actualizacion de pronosticos reales
	for (i=0;i<14;i++)
	{
		s=m_reja.GetItemText(i+1,6);
		CApuesta::pronostico[i].p1=atoi(s.GetBuffer(1024));
		s=m_reja.GetItemText(i+1,7);
		CApuesta::pronostico[i].px=atoi(s.GetBuffer(1024));
		s=m_reja.GetItemText(i+1,8);
		CApuesta::pronostico[i].p2=atoi(s.GetBuffer(1024));
	}

	//Actualizacion de pronosticos catetos
	for (i=0;i<14;i++)
	{
		s=m_reja.GetItemText(i+1,9);
		CApuesta::pronosticocateto[i].p1=atoi(s.GetBuffer(1024));
		s=m_reja.GetItemText(i+1,10);
		CApuesta::pronosticocateto[i].px=atoi(s.GetBuffer(1024));
		s=m_reja.GetItemText(i+1,11);
		CApuesta::pronosticocateto[i].p2=atoi(s.GetBuffer(1024));
	}

	//Actualizacion de solucion
	signo signos[14];
	for (int j=0;j<14;j++)
	{
		s=m_reja.GetItemText(j+1,1);
		const char *s2=s;
		signos[j]=s2[0];
	}
	CColumna ganadora(signos);
	m_manager->m_ganadora=ganadora;
}



void CQWDlg::OnCbnSelchangeCbjornada()
{
	bool bOK;
	int i=m_cbTemporada.GetCurSel();CString temporada;m_cbTemporada.GetLBText(i,temporada);
	int j=m_cbJornada.GetCurSel();CString jornada;m_cbJornada.GetLBText(j,jornada);
	char buf[10];
	memset(buf,0,10);memcpy(buf,temporada.GetBuffer(100)+5,4);
	m_manager->m_sTemporada=buf;
	memset(buf,0,10);sprintf(buf,"%02d",atoi(jornada.GetBuffer(100)));
	m_manager->m_sJornada=buf;

	m_manager->SeleccionarJornada(temporada,jornada);


	/*
	bool b;
	//CARGAMOS LOS PARTIDOS.
	b=m_manager->m_db->LoadPartidos(temporada, jornada);
	if (b) m_status->SetPaneText(0,"Partidos cargados"); else m_status->SetPaneText(0,"Error cargando partidos");

	//CARGAMOS EL RESULTADO
	m_status->SetPaneText(0,"Cargando el resultado");
	m_manager->m_ganadora=m_manager->m_db->LoadGanadora(m_manager->m_sTemporada.c_str(), jornada);

	m_status->SetPaneText(0,"Cargando los pronosticos");
	m_manager->m_db->LoadPronosticos(temporada, jornada);

	m_status->SetPaneText(0,"Cargando lo apostado");
	bOK=m_manager->m_db->LoadPronosticoApostado(temporada.GetBuffer(100),jornada.GetBuffer(100),CApuesta::pronosticocateto);
	if (!bOK) m_manager->m_apuesta->ResetPronostico(CApuesta::pronosticocateto);

	m_status->SetPaneText(0,"Cargando lo apostado");
	m_manager->m_db->LoadPremios(m_manager->m_sTemporada.c_str(), m_manager->m_sJornada.c_str());
	m_manager->m_db->LoadApuesta(m_manager->m_sTemporada,m_manager->m_sJornada,m_manager->m_apuesta);
	*/

	LlenarTodo();
	m_reja.Refresh();
}

void CQWDlg::LlenarTodo()
{
	LlenarPronosticos();
	LlenarApuesta();
	LlenarPartidos();
	LlenarGanadora();
	LlenarPremios();
	LlenarEscrutinio();
	LlenarEstadisticasApuesta(m_manager->m_apuesta);
	vector<CColumna *> vc=getSelCols();
	if (vc.size()==1)
		LlenarEstadisticasCol(vc[0]);
}

void CQWDlg::PrepararReja()
{
	m_reja.EnableTitleTips(false);
	m_reja.SetRowCount(15);
	m_reja.SetColumnCount(12+MAXCOLSHOWN);
	m_reja.SetFixedRowCount(1);
	m_reja.SetFixedColumnCount(1);
	for (int k=0;k<15;k++)
	{
		m_reja.SetRowHeight(k, 16);
		CString s;s.Format("%d",k);
		if(k) m_reja.SetItemText(k,0,s);
	}
	m_reja.SetColumnWidth(0, 32);
	m_reja.SetColumnWidth(1, 16);
	m_reja.SetColumnWidth(2, 168);
	for (int k=3;k<12;k++)
		m_reja.SetColumnWidth(k, 23);
	for (int k=12;k<12+MAXCOLSHOWN;k++)
		m_reja.SetColumnWidth(k, 12);
	m_reja.SetColumnResize(false);
	m_reja.SetRowResize(false);
	    for (int row = 1; row < m_reja.GetRowCount(); row++)
        {
	    	for (int col = 1; col < m_reja.GetColumnCount(); col++)
		    { 
                CString str;
			    GV_ITEM Item;
    			Item.mask = GVIF_TEXT;
	    		Item.row = row;
		    	Item.col = col;
                Item.strText = ".";
				if (col>2 && col<6)
					Item.crBkClr = 0xCCCCCC;        
				else if (col>5 && col<9)
					Item.crBkClr = 0xFFBBBB;
				else if (col>8 && col<12)
					Item.crBkClr = 0xFFBB99;
				else if (col==1)
					Item.crBkClr = 0xBBBBFF;
				else
					Item.crBkClr = 0xFFFFFF;        
                Item.crFgClr = col<3 ? 0x000000 : 0xFF0000;
				Item.nFormat = DT_SINGLELINE | DT_VCENTER | DT_LEFT ;
                Item.mask    |= (GVIF_FORMAT| GVIF_BKCLR|GVIF_FGCLR);
        		m_reja.SetItem(&Item);
			}
		}
		m_reja.SetItemText(0,3,"1");
		m_reja.SetItemText(0,4,"X");
		m_reja.SetItemText(0,5,"2");
		m_reja.SetItemText(0,6,"1");
		m_reja.SetItemText(0,7,"X");
		m_reja.SetItemText(0,8,"2");

		m_textcolumnasel.SetFont(m_fontcourier);
		m_stFilaComments.SetFont(m_fontcourier);
		m_textncols.SetFont(m_fontgorda);
		m_stPremioTotal.SetFont(m_fontgorda);

//		m_reja.SetVirtualMode(false);
	    UpdateData(FALSE);
		m_reja.SetRedraw(true,true);
}


void CQWDlg::LlenarPronosticos()
{
	CString s;
	for (int i=0;i<14;i++)
	{
		s.Format("%d",CApuesta::pronostico[i].p1);
		m_reja.SetItemText(i+1,6,s);
		s.Format("%d",CApuesta::pronostico[i].px);
		m_reja.SetItemText(i+1,7,s);
		s.Format("%d",CApuesta::pronostico[i].p2);
		m_reja.SetItemText(i+1,8,s);
		s.Format("%d",CApuesta::pronosticocateto[i].p1);
		m_reja.SetItemText(i+1,9,s);
		s.Format("%d",CApuesta::pronosticocateto[i].px);
		m_reja.SetItemText(i+1,10,s);
		s.Format("%d",CApuesta::pronosticocateto[i].p2);
		m_reja.SetItemText(i+1,11,s);
	}
}

void CQWDlg::LlenarApuesta()
{
	int aux;
	if (!m_manager->m_apuesta) 
		return;
	int maxRepresentedCols= min(m_manager->m_apuesta->getSize(),MAXCOLSHOWN);
	char txt[6];txt[1]=0;
	for (int i=0;i<MAXCOLSHOWN;i++)
	{
		for (int j=0;j<14;j++)
		{
			if (i<maxRepresentedCols)
			{
				txt[0]=getCharFromSigno(m_manager->m_apuesta->cols[i].var(j));
				if (m_manager->m_ganadora[j] != m_manager->m_apuesta->cols[i].var(j))
					m_reja.SetItemFgColour(j+1,i+12,0x0000FF);
				else
					m_reja.SetItemFgColour(j+1,i+12,0xFF0000);
			}
			else
				txt[0]=0;
			m_reja.SetItemText(j+1,i+12,txt);
		}
	}

	//Llena las estadisticas de uso de signos
	if (m_manager->m_apuesta->getSize()<1000)
	{
		for (int j=0;j<14;j++)
		{
			aux=m_manager->m_apuesta->ContarSignoPorCasilla(0,j);
			sprintf(txt,"%d",aux);
			m_reja.SetItemText(j+1,3,txt);
			aux=m_manager->m_apuesta->ContarSignoPorCasilla(1,j);
			sprintf(txt,"%d",aux);
			m_reja.SetItemText(j+1,4,txt);
			aux=m_manager->m_apuesta->ContarSignoPorCasilla(2,j);
			sprintf(txt,"%d",aux);
			m_reja.SetItemText(j+1,5,txt);

		}
	}
	

	m_reja.Refresh();
	LlenarEstadisticasApuesta(m_manager->m_apuesta);
}

void CQWDlg::LlenarGanadora()
{
	char txt[2];
	txt[1]=0;
	for (int j=0;j<14;j++)
	{
		txt[0]=getCharFromSigno(m_manager->m_ganadora[j]);
		m_reja.SetItemText(j+1,1,txt);
	}
}

void CQWDlg::LlenarPremios()
{
	CString s;
	s.Format("%d �",m_manager->m_premios.iRecaudacion);
	m_stRecaudacion.SetWindowText(s);
	s.Format("%d �",m_manager->m_premios.iPremio14);m_stPremi14.SetWindowText(s);
	s.Format("%d �",m_manager->m_premios.iPremio13);m_stPremi13.SetWindowText(s);
	s.Format("%d �",m_manager->m_premios.iPremio12);m_stPremi12.SetWindowText(s);
	s.Format("%d �",m_manager->m_premios.iPremio11);m_stPremi11.SetWindowText(s);
	s.Format("%d �",m_manager->m_premios.iPremio10);m_stPremi10.SetWindowText(s);
	s.Format("%d �",m_manager->m_premios.iPremio15);m_stPremi15.SetWindowText(s);
	s.Format("%d cents.",m_manager->m_premios.m_iPrecio);m_stPrecioApuesta.SetWindowText(s);

	s.Format("%d",m_manager->m_premios.m_iAcertantes15);m_stAcer15.SetWindowText(s);
	s.Format("%d",m_manager->m_premios.m_iAcertantes14);m_stAcer14.SetWindowText(s);
	s.Format("%d",m_manager->m_premios.m_iAcertantes13);m_stAcer13.SetWindowText(s);
	s.Format("%d",m_manager->m_premios.m_iAcertantes12);m_stAcer12.SetWindowText(s);
	s.Format("%d",m_manager->m_premios.m_iAcertantes11);m_stAcer11.SetWindowText(s);
	s.Format("%d",m_manager->m_premios.m_iAcertantes10);m_stAcer10.SetWindowText(s);

}

void CQWDlg::getSelJornada(string &temporada, string &jornada)
{
	CString s;
	int i=m_cbTemporada.GetCurSel();CString Stemporada;m_cbTemporada.GetLBText(i,Stemporada);
	int j=m_cbJornada.GetCurSel();CString sJornada;m_cbJornada.GetLBText(j,sJornada);
	temporada=Stemporada.GetBuffer(1000);
	if (strlen(temporada.c_str())==9){char buf[5];buf[4]=0;memcpy(buf,temporada.c_str()+5,4);temporada=buf;}
	jornada=sJornada.GetBuffer(1000);
}

void CQWDlg::LlenarEstadisticasFila(int fila)
{
	CString s;
	string temporada, jornada;
	getSelJornada(temporada, jornada);
	CPronostico pmarca[14];
	bool b= m_manager->m_db->LoadPronosticoMarca(temporada.c_str(),jornada.c_str(),pmarca);
	s.Format("%02d %02d %02d",pmarca[fila].p1,pmarca[fila].px,pmarca[fila].p2);
	if (b) m_stPronosMarca.SetWindowText(s);

	m_stEquipoLocal.SetWindowText("");
	m_stEquipoVisitante.SetWindowText("");
	pair<string,string> pss=m_manager->m_db->getEquipos(temporada,jornada.c_str(),fila+1);
	if (!pss.first.empty())	m_stEquipoLocal.SetWindowText(pss.first.c_str());
	if (!pss.second.empty()) m_stEquipoVisitante.SetWindowText(pss.second.c_str());

	CPronostico plosil[14], papues[14],papost[14];
	int iErrores;
	m_manager->m_db->getPorcentajeEstimado(temporada.c_str(),jornada.c_str(),plosil);
	m_manager->m_db->LoadPronosticoApuestas(temporada.c_str(),jornada.c_str(),papues,iErrores);
	m_manager->m_db->LoadPronosticoApostado(temporada.c_str(),jornada.c_str(),papost);

	CString sComment="";
	s.Format("Marca: %02d %02d %02d\n",pmarca[fila].p1,pmarca[fila].px,pmarca[fila].p2);sComment+=s;
	s.Format("Apues: %02d %02d %02d\n",papues[fila].p1,papues[fila].px,papues[fila].p2);sComment+=s;
	s.Format("Losil: %02d %02d %02d\n",plosil[fila].p1,plosil[fila].px,plosil[fila].p2);sComment+=s;
	s.Format("Apost: %02d %02d %02d\n",papost[fila].p1,papost[fila].px,papost[fila].p2);sComment+=s;
	m_stFilaComments.SetWindowText(sComment);
}


void CQWDlg::LlenarPartidos()
{
	if (m_manager->m_partidos.size()>=14)
		for (int j=0;j<14;j++)
		{
			m_reja.SetItemText(j+1,2,m_manager->m_partidos[j].c_str());
		}
}


void CQWDlg::LlenarEstadisticasApuesta(CApuesta *a)
{
	char *text=(char *)malloc(210);
	int col=a->getSize();
	sprintf(text,"%d",col);
	m_textncols.SetWindowText(text);


	float varmedia=a->getSize()<100000 ? a->getVariantesPromedio() : 0;
	sprintf(text,"Variantes: %.1f",varmedia);
	m_textApuestaVariantes.SetWindowText(text);

	varmedia= a->getSize()<100000 ? a->getProb14() : 0;	
	//	varmedia = a->getProb14();
	sprintf(text,"%.02E",varmedia);
	m_textProb14Media.SetWindowText(text);

	float rentabilmed= a->getSize()<100000 ? a->getRentabilMedia() : 0;	
	sprintf(text,"%.03f",rentabilmed);
	m_stRentabilMed.SetWindowText(text);



	if (col==0)
	{
		m_textApuestaVariantes.SetWindowText("Variantes: ");
		m_textProb14Media.SetWindowText("");
		m_stRentabilMed.SetWindowText("");
	}
	m_textPremios15.SetWindowText("");
	m_textpremios14.SetWindowText("");
	m_textpremios13.SetWindowText("");
	m_textpremios12.SetWindowText("");
	m_textpremios11.SetWindowText("");
	m_textpremios10.SetWindowText("");

	if (col<300)
	{
		CString s;
		m_manager->m_apuesta->Escrutar(m_manager->m_ganadora,UNO,m_manager->m_premios);
		LlenarEscrutinio();
	}


	free(text);
}

void CQWDlg::OnGridRClick(NMHDR *pNotifyStruct, LRESULT* pResult)
{
	NM_GRIDVIEW* pItem = (NM_GRIDVIEW*) pNotifyStruct;
	CString s=m_reja.GetItemText(pItem->iRow,pItem->iColumn);*pResult = 0;
	int numcol=pItem->iColumn-12;

	//SI HA CLICKADO EN UNA CASILLA NUEVA
	if (numcol>=m_manager->m_apuesta->getSize()) 
	{
		CMenu menu;
		menu.LoadMenu(IDR_COLUMNAV);
		CMenu* pPopup = menu.GetSubMenu(0);
		POINT point;GetCursorPos(&point);
		pPopup->TrackPopupMenu(TPM_LEFTALIGN | TPM_RIGHTBUTTON, point.x, point.y, this);
		//		{*pResult=-1;return;}
	}
	//SI HA CLICKADO EN UNA COLUMNA EXISTENTE
	else if (pItem->iColumn>11) 
	{
		CMenu menu;
		menu.LoadMenu(IDR_COLUMNA);
		CMenu* pPopup = menu.GetSubMenu(0);
		POINT point;GetCursorPos(&point);
		pPopup->TrackPopupMenu(TPM_LEFTALIGN | TPM_RIGHTBUTTON, point.x, point.y, this);
	}

}

void CQWDlg::LlenarEstadisticasCol(CColumna *c)
{
	char *s2=(char *)malloc(100);
	string s=c ? c->getString() : "";
	if (!c)
	{
		m_textnumbercol.SetWindowText("N�m.:");
		m_textFlag.SetWindowText("");
		m_textDistanciaMin.SetWindowText("Min.dist.: ");
		m_stAciertosSelCol.SetWindowText("0");
	}
	if (c)
	{
		float f=c->Probabilidad14(CApuesta::pronostico,false);
		sprintf(s2,"%.02E",f);
		m_textprob14.SetWindowText(s2);
		if (c->getFlag())
			m_textFlag.SetWindowText("O");
		else
			m_textFlag.SetWindowText("*");

		//SACAMOS LA RENTABILIDAD
		sprintf(s2,"%.03f",c->Rentabilidad(CApuesta::pronostico,CApuesta::pronosticocateto));
		m_stRentExacta.SetWindowText(s2);

		//SACAMOS LA MINIMA DISTANCIA
		sprintf(s2,"Min. distancia: %d",m_manager->m_apuesta->getSize()<1000 ? m_manager->m_apuesta->getMinDist(*c) : 0);
		for (int u=0;u<512;u++)
		{
			CColumna *c1=&m_manager->m_apuesta->cols[u];
			CColumna *c2=c;
			if (c1==c2)
			{
				sprintf(s2,"Min. distancia: %d",m_manager->m_apuesta->getSize()<1000 ? m_manager->m_apuesta->getMinDist(u) : 0);
			}
		}
		m_textDistanciaMin.SetWindowText(s2);

		//SACAMOS LOS ACIERTOS
		int iAciertos=c->Match(m_manager->m_ganadora);
		sprintf(s2,"%d",iAciertos);
		m_stAciertosSelCol.SetWindowText(s2);
	}
	m_textcolumnasel.SetWindowText(s.c_str());
	free(s2);
}

void CQWDlg::LlenarEscrutinio()
{
	CString s;
	s.Format("%d",m_manager->m_apuesta->m_iAciertos15);m_textPremios15.SetWindowText(s);
	s.Format("%d",m_manager->m_apuesta->m_iAciertos14);m_textpremios14.SetWindowText(s);
	s.Format("%d",m_manager->m_apuesta->m_iAciertos13);m_textpremios13.SetWindowText(s);	
	s.Format("%d",m_manager->m_apuesta->m_iAciertos12);m_textpremios12.SetWindowText(s);	
	s.Format("%d",m_manager->m_apuesta->m_iAciertos11);m_textpremios11.SetWindowText(s);	
	s.Format("%d",m_manager->m_apuesta->m_iAciertos10);m_textpremios10.SetWindowText(s);	
	//porque cada apuesta son 0,5 euros solo
	float fRenta=2*100*(float)m_manager->m_apuesta->m_iPremioTotal/(float)m_manager->m_apuesta->getSize();
	s.Format("%d�",m_manager->m_apuesta->m_iPremioTotal); //(%.0f%%) 
	m_stPremioTotal.SetWindowText(s);
}




void CQWDlg::OnArchivoAbrirapuestaNUEVO()
{
	CFileDialog dlg(true,"txt");
	int res=dlg.DoModal();
	if (res==IDCANCEL) return;
	CString filename=dlg.GetPathName();
	LeerApuesta(m_manager->m_apuesta,filename.GetBuffer());
}

void CQWDlg::OnArchivoGuardarapuesta32830()
{
	CFileDialog dlg(false,"txt");
	int res=dlg.DoModal();
	if (res==IDCANCEL) return;
	CString filename=dlg.GetPathName();
	GuardarApuesta(m_manager->m_apuesta, filename.GetBuffer());
}
