#include "stdafx.h"
#pragma warning (disable:4786)
#include <sstream>
#include <algorithm>

#include <xercesc/parsers/XercesDOMParser.hpp>
#include <xercesc/dom/DOM.hpp>
#include <xercesc/sax/HandlerBase.hpp>
#include <xercesc/util/XMLString.hpp>
#include <xercesc/util/PlatformUtils.hpp>

#include "../lib/qlib/source/conf.h"
#include "../lib/qlib/source/apuesta.h"
#include "../lib/qlib/source/pronostico.h"
#include "../lib/qlib/source/Qutil.h"
#include "QDB.h"
#include "conf.h"
#include "QW.h"
#include "QWDlg.h"
#include "GetNumberDlg.h"
#include "ColumnasFijasDlg.h"
#include "AboutDlg.h"
#include "QWManager.h"

XERCES_CPP_NAMESPACE_USE

/*
static string buffer;
//static char errorBuffer[CURL_ERROR_SIZE];
static int writer(char *data, size_t size, size_t nmemb,std::string *buffer)
{
	int result = 0;
	if (buffer != NULL)
	{
		buffer->append(data, size * nmemb);
		result = size * nmemb;
	}
	return result;
}
*/
string CQDB::DescargarApostadas(string jornada, string temporada)
{
	string sURL;
	sURL="http://www.quinielista.com/xml/porcentajes.asp?jornada=" + jornada;
	sURL += "&temporada="+temporada + "&tipo=T";
	string sFilename="./PorcentApostados/" + jornada+temporada+".xml";
	HRESULT hr=URLDownloadToFile(0,sURL.c_str(),sFilename.c_str(),0,0);
	return sFilename;
}

#pragma warning(disable: 4800)
CQDB::CQDB(class CQWManager *manager, CString archivo)
{
	m_manager=manager;
	CString sFile = archivo;   // or *.xls	
	CString sDriver = getDriver();    // "Microsoft Access Driver (*.mdb)"
	if (sDriver.IsEmpty()) return;
	m_sDsn.Format ("ODBC;DRIVER={%s};DSN='';DBQ=%s", sDriver, sFile );
	bool bOK=(bool)m_database.Open(NULL, false, false, m_sDsn );

	m_archivo=archivo;
}

CQDB::~CQDB()
{
	if (m_database.IsOpen())
		m_database.Close();
}

void CQDB::Actualizar()
{
	::SendMessage(AfxGetMainWnd()->GetSafeHwnd(),MSGQ_MSG,(WPARAM)"Importando hist�ricos...",0);
	ImportarJornadasLosilla(m_archivo);
	::SendMessage(AfxGetMainWnd()->GetSafeHwnd(),MSGQ_MSG,(WPARAM)"",0);


}
#pragma warning(disable: 4996)
string CQDB::getEquipoFromId(int id)
{
	string sIdEquipo="";
	if (m_database.IsOpen())
	{
		CString sql;
		char buf[128];sprintf(buf,"%d",id);
		sql="SELECT Equipo FROM Equipos WHERE IdEquipo=" + CString(buf) +"";
		CRecordset recset(&m_database);
		recset.Open ( CRecordset::forwardOnly, sql, CRecordset::readOnly );
		if (!recset.IsEOF())
		{
			CString s1;recset.GetFieldValue("Equipo", s1 );
			sIdEquipo=s1.GetBuffer();
		}
	}
	return sIdEquipo;

}

string CQDB::getIdFromEquipo(string sEquipo)
{
	string sIdEquipo="";
	if (m_database.IsOpen())
	{
		CString sql;
		sql="SELECT IdEquipo FROM Equipos WHERE Equipo='" + CString(sEquipo.c_str()) +"'";
		CRecordset recset(&m_database);
		recset.Open ( CRecordset::forwardOnly, sql, CRecordset::readOnly );
		if (!recset.IsEOF())
		{
			CString s1;recset.GetFieldValue("IdEquipo", s1 );
			sIdEquipo=s1.GetBuffer();
		}
	}
	return sIdEquipo;
}

void CQDB::ImportarJornadasApostadas()
{
	for (int j=2008;j>2000;j--)
	{
		char buf2[10];sprintf(buf2,"%d",j);
		for (int i=1;i<42;i++)
		{
			char buf[10];sprintf(buf,"%d",i);
			string sFilename=DescargarApostadas(buf,buf2);
			if (!sFilename.empty())
			{
				string sComment="Descargado " + sFilename;
				::SendMessage(AfxGetMainWnd()->GetSafeHwnd(),MSGQ_MSG,(WPARAM)sComment.c_str(),0);
				if (!sFilename.empty()) ImportJugadasXML(sFilename);
			}
		}
	}
	::SendMessage(AfxGetMainWnd()->GetSafeHwnd(),MSGQ_MSG,(WPARAM)"Listo",0);
}

void CQDB::ImportarJornadasLosilla(CString archivo)
{
	CString sURLJornadas="http://www.megaquin1x2.com/jornadas.mdb";
	URLDownloadToFile(0,sURLJornadas,"jornadas.mdb",0,0);
	CString sql;

	//IMPORTAR LA TABLA JORNADASLOSILLA TAL CUAL
	try{
		sql="DROP TABLE JornadasLosilla";
		m_database.ExecuteSQL(sql);
	}catch(...){};
	try{
		sql="SELECT * INTO [" + archivo+ "].JornadasLosilla FROM [jornadas.mdb].Jornadas";
		m_database.ExecuteSQL(sql);
	}catch(...){};


	//IMPORTAR LA RECAUDACION
	try{
		sql="INSERT INTO Premios (Temporada, Jornada, Recaudacion, Premio15, Premio14, Premio13, Premio12, Premio11, Premio10) SELECT Temporada, Jornada, Recaud, EL15, EL14, EL13,EL12,EL11,EL10 FROM JornadasLosilla";
		m_database.ExecuteSQL(sql);
	}catch(...){};


	//IMPORT GANADORAS FROM LOSILLA
	CColumna ganadora;
	CString sig;
	for (int iTemp=1989;iTemp<2010;iTemp++)
	{
		char sTemp[128];sprintf(sTemp,"%d",iTemp);
		int maxJor=getJornadas(sTemp).size();
		signo pleno15;
		for (int iJor=01;iJor<maxJor;iJor++)
		{
			char sJor[128];sprintf(sJor,"%02d",iJor);
			CString temporada=sTemp;
			CString jornada=sJor;
			if (strlen(temporada)==4) temporada.Format("%d/%d",atoi(temporada)-1,atoi(temporada));
			CRecordset recset(&m_database);
			sql.Format("SELECT SIG1,SIG2,SIG3,SIG4,SIG5,SIG6,SIG7,SIG8,SIG9,SIG10,SIG11,SIG12,SIG13,SIG14,SIG15 from JORNADASLOSILLA WHERE Temporada='%s' AND Jornada='%s'",temporada,jornada);
			recset.Open ( CRecordset::forwardOnly, sql, CRecordset::readOnly );
			if(!recset.IsEOF())	
			{
				signo lista[14];
				char scol[16];
				for(int k=1;k<=14;k++)
				{
					CString stmp;stmp.Format("SIG%d",k);
					recset.GetFieldValue(stmp, sig);lista[k-1] = (sig == '1') ? UNO : ((sig== '2') ? DOS : EQUIS);
					scol[k-1]=sig.GetAt(0);
				}
				recset.GetFieldValue("SIG15", sig);
				pleno15 = (sig == '1') ? UNO : ((sig== '2') ? DOS : EQUIS);
				scol[14]=sig.GetAt(0);
				scol[15]=0;
				try{
					sql.Format("INSERT INTO Ganadoras (Temporada, Jornada, Ganadora) VALUES ('%s','%s','%s')",sTemp,jornada,scol);
					m_database.ExecuteSQL(sql);
				}catch(...){} //si ya est� relleno el dato no pasa nada.
			}
		}
	}
}

void CQDB::ImportJugadasXML(string sFile)
{
	const char* xmlFile = sFile.c_str();
	string sJornada;
	string sTemporada;
	string sNum;
	string sLocal, sVisitante;
	string sUno, sEquis, sDos;
	CPronostico pronosLosilla;

	XMLPlatformUtils::Initialize();
	XercesDOMParser* parser = new XercesDOMParser();
	parser->setValidationScheme(XercesDOMParser::Val_Always);    
	parser->setDoNamespaces(true);    // optional
	ErrorHandler* errHandler = (ErrorHandler*) new HandlerBase();
	parser->setErrorHandler(errHandler);
	parser->parse(xmlFile);
	DOMNode *doc = parser->getDocument();
	DOMNode *quinielista=doc->getFirstChild();
	string s2= XMLString::transcode(quinielista->getNodeName());
	DOMNode *porcentajes=quinielista->getFirstChild();porcentajes=porcentajes->getNextSibling();
	string s= XMLString::transcode(porcentajes->getNodeName());
	DOMNamedNodeMap *jorAttributes=porcentajes->getAttributes();
	int nSize = jorAttributes->getLength();
	for(int i=0;i<nSize;++i) 
	{
		DOMAttr *jorAttributeNode = (DOMAttr*) jorAttributes->item(i);
		string nombre = XMLString::transcode(jorAttributeNode->getName());
		string valor = XMLString::transcode(jorAttributeNode->getValue());
		if (nombre=="jornada") sJornada=valor;
		if (nombre=="temporada") sTemporada=valor;
	}
	DOMNode *partido=porcentajes->getFirstChild();partido=partido->getNextSibling();
	do{
		string sq=XMLString::transcode(partido->getNodeName());
		DOMNamedNodeMap *parAttributes=partido->getAttributes();
		nSize = parAttributes->getLength();
		for(int i=0;i<nSize;++i) 
		{
			DOMAttr *parAttributeNode = (DOMAttr*) parAttributes->item(i);
			string nombre = XMLString::transcode(parAttributeNode->getName());
			string valor = XMLString::transcode(parAttributeNode->getValue());
			if (nombre=="num") sNum=valor;
			if (nombre=="local") sLocal=valor;
			if (nombre=="visitante") sVisitante=valor;
			if (nombre=="porc_1") sUno=valor;
			if (nombre=="porc_X") sEquis=valor;
			if (nombre=="porc_2") sDos=valor;
		}
		string sIdLocal=getIdFromEquipo(sLocal);
		string sIdVisitante=getIdFromEquipo(sVisitante);

		if (sIdLocal.empty()) sIdLocal=InsertEquipo(sLocal);
		if (sIdVisitante.empty()) sIdVisitante=InsertEquipo(sVisitante);

		try{
			string sql="INSERT INTO Jornada (Temporada, Jornada, Partido, IdEquipoLocal, IdEquipoVisitante) ";
			sql += " VALUES ('" + sTemporada + "','" + sJornada + "','" + sNum +"','" + sIdLocal + "','" + sIdVisitante + "')";
			m_database.ExecuteSQL(CString(sql.c_str()));
		}catch(...){}

		try{
			string sql="INSERT INTO PorcentajesApostados (Temporada, Jornada, Partido, Uno, Equis, Dos) ";
			sql += " VALUES ('" + sTemporada + "','" + sJornada + "','" + sNum +"','" + sUno+ "','" + sEquis + "','" + sDos +"')";
			m_database.ExecuteSQL(CString(sql.c_str()));
		}catch(...){}

		partido=partido->getNextSibling();
		if (partido) partido=partido->getNextSibling();
	}while(partido);



	//XMLPlatformUtils::Terminate();
	delete parser;
	delete errHandler;
}

string CQDB::InsertEquipo(string sEquipo)
{
	if (!m_database.IsOpen()) return "";	
	CString sql=CString("INSERT INTO Equipos (Equipo) VALUES ('") + CString(sEquipo.c_str()) + CString("')");
	m_database.ExecuteSQL(sql);
	return getIdFromEquipo(sEquipo);
}

pair<string,string> CQDB::getEquipos(string sTemporada, string sJornada, int iPartido)
{
	pair<string,string> ps;
	//Obtenemos el equipo local
	if (!m_database.IsOpen()) return ps;	
	CRecordset recset(&m_database);
	char buf[10];CString p1, sql;
	sql="SELECT Equipo FROM Equipos, EquiposJornada WHERE Equipos.IdEquipo=EquiposJornada.IdEquipoLocal AND EquiposJornada.Temporada = '";
	sql+= CString(sTemporada.c_str()) + CString("' AND EquiposJornada.Jornada = '") + CString(sJornada.c_str());
	sql+= CString("' AND EquiposJornada.Partido = '") + CString(itoa(iPartido,buf,10)) + CString("'");
	recset.Open ( CRecordset::forwardOnly, sql, CRecordset::readOnly );
	if (!recset.IsEOF())recset.GetFieldValue("Equipo", p1 );
	ps.first=p1.GetBuffer(1000);
	recset.Close();

	sql="SELECT Equipo FROM Equipos, EquiposJornada WHERE Equipos.IdEquipo=EquiposJornada.IdEquipoVisitante AND EquiposJornada.Temporada = '";
	sql+= CString(sTemporada.c_str()) + CString("' AND EquiposJornada.Jornada = '") + CString(sJornada.c_str());
	sql+= CString("' AND EquiposJornada.Partido = '") + CString(itoa(iPartido,buf,10)) + CString("'");
	recset.Open ( CRecordset::forwardOnly, sql, CRecordset::readOnly );
	if (!recset.IsEOF())recset.GetFieldValue("Equipo", p1 );
	ps.second=p1.GetBuffer(1000);
	return ps;
}

vector<string> CQDB::getJornadas(string sTemporada)
{
	vector<string> sJornadas;
	if (!m_database.IsOpen()) return sJornadas;

	CString temporada(sTemporada.c_str());
	if (strlen(temporada)==4) temporada.Format("%d/%d",atoi(temporada)-1,atoi(temporada));
	sTemporada=temporada.GetBuffer();

	CRecordset recset(&m_database);
	CString sql="SELECT Jornada from JornadasLosilla WHERE Temporada='";
	sql += CString(sTemporada.c_str());
	sql += "'";
	recset.Open ( CRecordset::forwardOnly, sql, CRecordset::readOnly );

	while ( !recset.IsEOF() )  
	{
		CString s1;
		recset.GetFieldValue("Jornada", s1 );
		sJornadas.push_back(s1.GetBuffer(1000));
		recset.MoveNext();          // if multiple records to consider, move to next
	}
	return sJornadas;
}

/**
* Obtiene las jornadas de jornadas de Losilla (!?)
*/
vector<string> CQDB::getTemporadas()
{
	vector<string> sTemporadas;
	if (!m_database.IsOpen()) return sTemporadas;

	CRecordset recset(&m_database);
	CString sql="SELECT DISTINCT Temporada from JornadasLosilla";
	recset.Open ( CRecordset::forwardOnly, sql, CRecordset::readOnly );
	while ( !recset.IsEOF() )  
	{
		CString s1;
		recset.GetFieldValue("Temporada", s1 );
		sTemporadas.push_back(s1.GetBuffer(1000));
		recset.MoveNext();          // if multiple records to consider, move to next
	}
	return sTemporadas;
}



bool CQDB::LoadPremios(CString temporada, CString jornada)
{
	m_manager->m_premios.ResetPremios();

	if (!m_database.IsOpen()) return false;
	CRecordset recset2(&m_database);
	CString sql,sig,s1,stmp;
	sql.Format("SELECT Precio FROM Precio WHERE Temporada='%s'",temporada);
	recset2.Open ( CRecordset::forwardOnly, sql, CRecordset::readOnly );
	if(recset2.IsEOF()) 
	{
		return false;
	}
	else
	{
		recset2.GetFieldValue("Precio", s1);
		m_manager->m_premios.m_iPrecio=atoi(s1);
	}

	float factor=1;
	if (atoi(temporada)<=2002) factor=166.386; else factor=100;
	if (strlen(temporada)==4) temporada.Format("%d/%d",atoi(temporada)-1,atoi(temporada));

	sql.Format("SELECT Recaudacion,Premio15,Premio14,Premio13,Premio12,Premio11,Premio10 from Premios WHERE Temporada='%s' AND Jornada='%s'",temporada,jornada);
	CRecordset recset(&m_database);
	recset.Open ( CRecordset::forwardOnly, sql, CRecordset::readOnly );
	if(!recset.IsEOF())	
	{
		recset.GetFieldValue("Recaudacion", s1);m_manager->m_premios.iRecaudacion=atoi(s1.GetBuffer(100))/factor;
		recset.GetFieldValue("Premio15", s1);m_manager->m_premios.iPremio15=atoi(s1.GetBuffer(100))/factor;
		recset.GetFieldValue("Premio14", s1);m_manager->m_premios.iPremio14=atoi(s1.GetBuffer(100))/factor;
		recset.GetFieldValue("Premio13", s1);m_manager->m_premios.iPremio13=atoi(s1.GetBuffer(100))/factor;
		recset.GetFieldValue("Premio12", s1);m_manager->m_premios.iPremio12=atoi(s1.GetBuffer(100))/factor;
		recset.GetFieldValue("Premio11", s1);m_manager->m_premios.iPremio11=atoi(s1.GetBuffer(100))/factor;
		recset.GetFieldValue("Premio10", s1);m_manager->m_premios.iPremio10=atoi(s1.GetBuffer(100))/factor;
	}

	sql.Format("SELECT * from HISTORICO WHERE Temporada='%s' AND Jornada='%d'",temporada,atoi(jornada));
	CRecordset recset4(&m_database);
	recset4.Open ( CRecordset::forwardOnly, sql, CRecordset::readOnly );
	if(!recset4.IsEOF())	
	{
		recset4.GetFieldValue("AC15", s1);m_manager->m_premios.m_iAcertantes15=atoi(s1.GetBuffer(100));
		recset4.GetFieldValue("AC14", s1);m_manager->m_premios.m_iAcertantes14=atoi(s1.GetBuffer(100));
		recset4.GetFieldValue("AC13", s1);m_manager->m_premios.m_iAcertantes13=atoi(s1.GetBuffer(100));
		recset4.GetFieldValue("AC12", s1);m_manager->m_premios.m_iAcertantes12=atoi(s1.GetBuffer(100));
		recset4.GetFieldValue("AC11", s1);m_manager->m_premios.m_iAcertantes11=atoi(s1.GetBuffer(100));
		recset4.GetFieldValue("AC10", s1);m_manager->m_premios.m_iAcertantes10=atoi(s1.GetBuffer(100));
	}
	return true;
}

CColumna CQDB::LoadGanadora(CString temporada, CString jornada, signo *pleno15)
{
	CColumna ganadora;
	if (!m_database.IsOpen()) return ganadora;
	CString sql;
	CRecordset recset(&m_database);
	sql.Format("SELECT Ganadora from GANADORAS WHERE Temporada='%s' AND Jornada='%s'",temporada,jornada);
	recset.Open ( CRecordset::forwardOnly, sql, CRecordset::readOnly );
	if(!recset.IsEOF())	
	{
		CString stmp;stmp.Format("Ganadora");
		CString sGanadora;
		recset.GetFieldValue(stmp, sGanadora);
		CColumna sganadora(sGanadora.GetBuffer(1000));
		return sganadora;	
	}

	/*
	CString sig;
	if (strlen(temporada)==4) temporada.Format("%d/%d",atoi(temporada)-1,atoi(temporada));
	sql.Format("SELECT SIG1,SIG2,SIG3,SIG4,SIG5,SIG6,SIG7,SIG8,SIG9,SIG10,SIG11,SIG12,SIG13,SIG14,SIG15 from JORNADASLOSILLA WHERE Temporada='%s' AND Jornada='%s'",temporada,jornada);
	recset.Open ( CRecordset::forwardOnly, sql, CRecordset::readOnly );
	if(!recset.IsEOF())	
	{
		signo lista[14];
		for(int k=1;k<=14;k++)
		{
			CString stmp;stmp.Format("SIG%d",k);
			recset.GetFieldValue(stmp, sig);lista[k-1] = (sig == '1') ? UNO : ((sig== '2') ? DOS : EQUIS);
		}
		if (pleno15)
		{
			recset.GetFieldValue("SIG15", sig);
			*pleno15 = (sig == '1') ? UNO : ((sig== '2') ? DOS : EQUIS);
		}

		return CColumna(lista);
	}
	*/
	return ganadora;
}

/**
* Esta funcion carga los pronosticos reales para una temporada/joranda dadas.
*/
void CQDB::LoadPronosticos(CString temporada, CString jornada)
{
	int iErrores;
	LoadPronosticoApuestas(temporada.GetBuffer(),jornada.GetBuffer(),CApuesta::pronostico, iErrores);
	return;
	/*
	if (!m_database.IsOpen()) return;
	CString sql;
	CString sig;
	for (int i=0;i<14;i++)
	{
		CRecordset recset(&m_database);
		CString j;j.Format("PTP%d1, PTP%dX, PTP%d2",i+1,i+1,i+1);
		CString j1;j1.Format("PTP%d1",i+1);
		CString jx;jx.Format("PTP%dX",i+1);
		CString j2;j2.Format("PTP%d2",i+1);
		j="SELECT " + j;
		sql.Format(" FROM JornadasLosilla WHERE Temporada='%s' AND Jornada='%s'",temporada,jornada);
		sql=j+sql;
		recset.Open ( CRecordset::forwardOnly, sql, CRecordset::readOnly );
		if(!recset.IsEOF())	
		{
			CString s;
			
			recset.GetFieldValue(j1,s);CApuesta::pronostico[i].p1=atoi(s.GetBuffer(1000));
			recset.GetFieldValue(jx,s);CApuesta::pronostico[i].px=atoi(s.GetBuffer(1000));
			recset.GetFieldValue(j2,s);CApuesta::pronostico[i].p2=atoi(s.GetBuffer(1000));
		}
	}
	*/
}

bool CQDB::LoadPronosticoApostado(string temporada, string jornada, CPronostico pron[14])
{
	if (!pron) return false;

	if (strlen(temporada.c_str())==9)
	{char buf[5];buf[4]=0;memcpy(buf,temporada.c_str()+5,4);temporada=buf;}

	if (!m_database.IsOpen()) return false;

	for (int i=1;i<15;i++)
	{
		char bufn[10];sprintf(bufn,"%d",i);
		CRecordset recset(&m_database);
		string sql="SELECT uno, equis, dos from PorcentajesApostados WHERE Temporada='";
		sql += temporada;
		sql += "' AND Jornada = '" + jornada + "'";
		sql += " AND Partido='" + string(bufn) +"'";
		recset.Open ( CRecordset::forwardOnly, sql.c_str(), CRecordset::readOnly );
		if (recset.IsEOF()) 
			return false;
		while ( !recset.IsEOF() )  
		{
			CString s1;recset.GetFieldValue("uno", s1 );
			float f1=atof(s1.GetBuffer(1000));
			CString sx;recset.GetFieldValue("equis", sx );
			float fx=atof(sx.GetBuffer(1000));
			CString s2;recset.GetFieldValue("dos", s2 );
			float f2=atof(s2.GetBuffer(1000));
			CPronostico pronoApostado;
			bool bOK=pronoApostado.Redondear(f1,fx,f2);
			//if (!bOK) AfxMessageBox("Error cargando porcentajes");
			pron[i-1] = pronoApostado;
			recset.MoveNext();          // if multiple records to consider, move to next
		}
	}
	return true;
}


bool CQDB::LoadPartidos(CString temporada, CString jornada )
{
	bool bOK=false;
	if (strlen(temporada)==4) temporada.Format("%d/%d",atoi(temporada)-1,atoi(temporada));
	if (!m_database.IsOpen()) return false;

	CString sql;
	CString partido;
	CRecordset recset(&m_database);
	sql.Format("SELECT P1,P2,P3,P4,P5,P6,P7,P8,P9,P10,P11,P12,P13,P14 from JORNADASLOSILLA WHERE Temporada='%s' AND Jornada='%s'",temporada,jornada);
	recset.Open ( CRecordset::forwardOnly, sql, CRecordset::readOnly );
	if(!recset.IsEOF())	
	{
		bOK=true;
		m_manager->m_partidos.clear();
		recset.GetFieldValue("P1", partido );m_manager->m_partidos.push_back(partido.GetBuffer(1000));
		recset.GetFieldValue("P2", partido );m_manager->m_partidos.push_back(partido.GetBuffer(1000));
		recset.GetFieldValue("P3", partido );m_manager->m_partidos.push_back(partido.GetBuffer(1000));
		recset.GetFieldValue("P4", partido );m_manager->m_partidos.push_back(partido.GetBuffer(1000));
		recset.GetFieldValue("P5", partido );m_manager->m_partidos.push_back(partido.GetBuffer(1000));
		recset.GetFieldValue("P6", partido );m_manager->m_partidos.push_back(partido.GetBuffer(1000));
		recset.GetFieldValue("P7", partido );m_manager->m_partidos.push_back(partido.GetBuffer(1000));
		recset.GetFieldValue("P8", partido );m_manager->m_partidos.push_back(partido.GetBuffer(1000));
		recset.GetFieldValue("P9", partido );m_manager->m_partidos.push_back(partido.GetBuffer(1000));
		recset.GetFieldValue("P10", partido );m_manager->m_partidos.push_back(partido.GetBuffer(1000));
		recset.GetFieldValue("P11", partido );m_manager->m_partidos.push_back(partido.GetBuffer(1000));
		recset.GetFieldValue("P12", partido );m_manager->m_partidos.push_back(partido.GetBuffer(1000));
		recset.GetFieldValue("P13", partido );m_manager->m_partidos.push_back(partido.GetBuffer(1000));
		recset.GetFieldValue("P14", partido );m_manager->m_partidos.push_back(partido.GetBuffer(1000));
	}
	recset.Close();
	return bOK;
}

CString CQDB::getDriver()
{
	WORD cbBufMax = 2000;
	WORD cbBufOut;
	char szBuf[2001];	char *pszBuf = szBuf;
	CString sDriver="";
	if ( !SQLGetInstalledDrivers (szBuf, cbBufMax, &cbBufOut) ) 
	{
		sDriver="";
	}
	else {
		do {
			if ( strstr(pszBuf, "Access" ) != 0 ) // tambien valdria para Excel!!
			{
				sDriver=CString(pszBuf);
				break;
			}
			pszBuf = strchr(pszBuf, '\0') +1;
		}
		while (pszBuf[1]!='\0');
	}
	return sDriver;
}

bool CQDB::getPorcentajeEstimado(string temporada,string jornada, CPronostico *pron)
{
	if (!pron) return false;

	for (int i=1;i<15;i++)
	{
		char bufn[10];sprintf(bufn,"%d",i);
		CRecordset recset(&m_database);
		string sql="SELECT uno, equis, dos from PorcentajesEstimados WHERE Temporada='";
		sql += temporada;
		sql += "' AND Jornada = '" + jornada + "'";
		sql += " AND Partido='" + string(bufn) +"'";
		recset.Open ( CRecordset::forwardOnly, sql.c_str(), CRecordset::readOnly );
		while ( !recset.IsEOF() )  
		{
			CString s1;recset.GetFieldValue("uno", s1 );
			float f1=atof(s1.GetBuffer(1000));
			CString sx;recset.GetFieldValue("equis", sx );
			float fx=atof(sx.GetBuffer(1000));
			CString s2;recset.GetFieldValue("dos", s2 );
			float f2=atof(s2.GetBuffer(1000));
			CPronostico pronoApostado;
			pronoApostado.Redondear(f1,fx,f2);
			pron[i-1] = pronoApostado;
			recset.MoveNext();          // if multiple records to consider, move to next
		}
	}
	return true;
};
/*
bool CQDB::getPremios(string temporada, string jornada, int *p15, int *p14, int *p13, int *p12, int *p11, int *p10, int *recaudacion)
{
	
	return false;
}*/

void CQDB::ImportMarca()
{
	FILE *f=fopen("HistoricoMarca.txt","r");
	char temporada[25];
	int iJor;
	CString sql="DELETE * FROM PorcentajesMarca";
//	m_database.ExecuteSQL(sql);

	while (!feof(f))
	{
		fscanf(f,"%s %d",temporada,&iJor);

		for (int i=1;i<=14;i++)
		{
			float f1,fx,f2;
			fscanf (f,"%f %f %f", &f1,&fx,&f2);
			try{
				CString sql;
				sql.Format("INSERT INTO PorcentajesMarca (Temporada, Jornada, Partido, Uno, Equis, Dos) VALUES ('%s', '%02d', '%d', '%.2f','%.2f','%.2f')",&temporada[5], iJor, i,f1,fx,f2);
				m_database.ExecuteSQL(sql);
			}catch(...){}

		}

	}
	fclose(f);
}

bool CQDB::LoadPronosticoMarca(CString temporada, CString jornada, CPronostico pron[14])
{
	if (!pron) return false;
	string sTemporada=temporada;
	if (strlen(sTemporada.c_str())==9){char buf[5];buf[4]=0;memcpy(buf,sTemporada.c_str()+5,4);sTemporada=buf;}
	temporada=sTemporada.c_str();

	if (!m_database.IsOpen()) return false;

	for (int i=1;i<15;i++)
	{
		char bufn[10];sprintf(bufn,"%d",i);
		CRecordset recset(&m_database);
		string sql="SELECT uno, equis, dos from PorcentajesMarca WHERE Temporada='";
		sql += temporada;
		sql += "' AND Jornada = '" + jornada + "'";
		sql += " AND Partido='" + string(bufn) +"'";
		recset.Open ( CRecordset::forwardOnly, sql.c_str(), CRecordset::readOnly );
		if (recset.IsEOF()) 
			return false;
		while ( !recset.IsEOF() )  
		{
			CString s1;recset.GetFieldValue("uno", s1 );
			float f1=atof(s1.GetBuffer(1000));
			CString sx;recset.GetFieldValue("equis", sx );
			float fx=atof(sx.GetBuffer(1000));
			CString s2;recset.GetFieldValue("dos", s2 );
			float f2=atof(s2.GetBuffer(1000));
			CPronostico pronoApostado;
			pronoApostado.Redondear(f1,fx,f2);
			pron[i-1] = pronoApostado;

			
			recset.MoveNext();          // if multiple records to consider, move to next
		}
	}
	return true;
}
bool CQDB::SaveApuesta(string sTemporada,string sJornada,class CApuesta *apuesta)
{
	if (!m_database.IsOpen()) return false;
	CWaitCursor wc;
	try{
		string sql="DELETE * FROM Apuesta ";
		sql += " WHERE Temporada='" + sTemporada + "' AND Jornada='" + sJornada + "'";
		m_database.ExecuteSQL(CString(sql.c_str()));
	}catch(...){return false;}
	for (int i=0;i<apuesta->getSize();i++)
	{
		string sApuesta=apuesta->cols[i].getString();
		try{
			string sql="INSERT INTO Apuesta (Temporada, Jornada, Columna) ";
			sql += " VALUES ('" + sTemporada + "','" + sJornada + "','" + sApuesta +"')";
			m_database.ExecuteSQL(CString(sql.c_str()));
		}catch(...){return false;}
	}
	return true;
}
bool CQDB::LoadApuesta(string sTemporada,string sJornada, CApuesta *apuesta)
{
	if (!m_database.IsOpen()) return false;
	CWaitCursor wc;

	apuesta->setSize(0);
	CRecordset recset(&m_database);
	string sql="SELECT columna from Apuesta WHERE Temporada='";
	sql += sTemporada;
	sql += "' AND Jornada = '" + sJornada + "'";
	recset.Open ( CRecordset::forwardOnly, sql.c_str(), CRecordset::readOnly );
	while ( !recset.IsEOF() )  
	{
		CString s1;recset.GetFieldValue("columna", s1 );
		string sCol=s1;
		CColumna c(sCol.c_str());
		apuesta->InsertarAlloc(c);
		recset.MoveNext();          // if multiple records to consider, move to next
	}


	return true;
}


bool CQDB::SavePronostico(CString temporada, CString jornada, CPronostico p[14])
{
	/*
	CString sql;
	CString ratio1, ratiox, ratio2;
	sql.Format("DELETE * FROM ProcentajesCasasApuestas WHERE Temporada='%s' AND Jornada='%s'",temporada,jornada);
	m_database.ExecuteSQL(sql);
	sql.Format("INSERT INTO PorcentajesCasasApuestas (Temporada, Jornada, Partido, Ratio1, Ratiox, Ratio2) VALUES ('%s','%s','%s')",temporada,jornada,partido,ratio1,ratiox,ratio2);
	m_database.ExecuteSQL(sql);*/
	return false;
}


bool CQDB::SaveGanadora(CString temporada, CString jornada, CColumna ganadora)
{
	CString sql;
	string sGanadora=ganadora.getString();
	sql.Format("DELETE * FROM Ganadoras WHERE Temporada='%s' AND Jornada='%s'",temporada,jornada);
	m_database.ExecuteSQL(sql);
	sql.Format("INSERT INTO Ganadoras (Temporada, Jornada, Ganadora) VALUES ('%s','%s','%s')",temporada,jornada,sGanadora.c_str());
	m_database.ExecuteSQL(sql);
	return true;
}
float getP14(CColumna ganadora, CPronostico prono[14])
{
	float p=1;
	for (int i=0;i<14;i++)
	{
		if (ganadora[i]==UNO) 
			p*= ((float)prono[i].p1/100);
		if (ganadora[i]==EQUIS) 
			p*= ((float)prono[i].px/100);
		if (ganadora[i]==DOS) 
			p*= ((float)prono[i].p2/100);
		if (ganadora[i]==BLANCO) 
			return -1;
	}
	return p;
}

class mystring : public string
{

};
float CQDB::EvaluarPronosticoTemporada(string sTemporada)
{
	string sFile="C:\\prob" + sTemporada + string(".txt");
	FILE *f=fopen(sFile.c_str(),"w");
	int iTotJor=getJornadas(sTemporada).size();
	float fTotal=0;
	int iTotal=0;
	for (int i=1;i<=iTotJor;i++)
	{
		bool b;
		int iErrores=0;
		char buf[30];sprintf(buf,"%02d",i);string sJornada=buf;
		CColumna colGanadora=LoadGanadora(sTemporada.c_str(),sJornada.c_str(),NULL);
//		b=getPorcentajeEstimado(sTemporada,sJornada,CApuesta::pronostico);
//		b=LoadPronosticoApuestas(sTemporada,sJornada,CApuesta::pronostico, iErrores);
//		b=LoadPronosticoMarca(sTemporada.c_str(),sJornada.c_str(),CApuesta::pronostico);
		b=LoadPronosticoApostado(sTemporada.c_str(),sJornada.c_str(),CApuesta::pronostico);
		if (!b) continue;
		float fJor=getP14(colGanadora,CApuesta::pronostico);
		if (fJor==-1) 
		{
			continue;
		}
		fTotal+=fJor;
		iTotal++;
		fprintf(f,"%02d \t %02d \t %6f\n",iErrores, i,1000000*(double)fJor);
	}
	fTotal/=iTotal;
	fclose(f);
	return fTotal;
}

void CQDB::Joker()
{
//	CasarJornadas();return;
	for (int iYear=2001;iYear<2009;iYear++)
	{
		char buf[100];
		sprintf(buf,"%d",iYear);
		float f=EvaluarPronosticoTemporada(buf);
		sprintf(buf,"%E",f);
//		AfxMessageBox(buf);
	}
}
// ojo, temporada 2002, jornada 04 (de liga 3) partido 8, es sobreescrito por jornada 40, partido de copa....
//Disponible desde la temporada 1999
bool CQDB::LoadPronosticoApuestas(string temporada, string jornada, class CPronostico pron[14], int &iErrores)
{
	iErrores=0;
	float f1, fx,f2;
	CPronostico pronoApostado;

	if (!pron) return false;
	string sTemporada=temporada;
	if (strlen(sTemporada.c_str())==9){char buf[5];buf[4]=0;memcpy(buf,sTemporada.c_str()+5,4);sTemporada=buf;}
	temporada=sTemporada.c_str();

	if (!m_database.IsOpen()) return false;

	for (int i=1;i<15;i++)
	{
		char bufn[10];sprintf(bufn,"%d",i);
		CRecordset recset(&m_database);
		string sql="SELECT Ratio1, Ratiox, Ratio2 from PorcentajesCasasApuestas WHERE Temporada='";
		sql += temporada;
		sql += "' AND Jornada = '" + jornada + "'";
		sql += " AND Partido='" + string(bufn) +"'";
		recset.Open ( CRecordset::forwardOnly, sql.c_str(), CRecordset::readOnly );
		if (recset.IsEOF()) 
		{
			string sql2="SELECT Local,Visitante from PorcentajesCasasApuestas WHERE Temporada='";
			sql2 += temporada;
			sql2 += "' AND Jornada = '" + jornada + "'";
			sql2 += " AND Partido='" + string(bufn) +"'";
			CRecordset recset2(&m_database);
			recset2.Open ( CRecordset::forwardOnly, sql2.c_str(), CRecordset::readOnly );
			string mense=bufn;
			if (!recset.IsEOF()) 
			{
				CString s5;recset.GetFieldValue("Local", s5 );
				CString s6;recset.GetFieldValue("Visitante", s6 );
				mense = string(s5.GetBuffer(100))+string(" ")+string(s6.GetBuffer(100));
			}
			recset2.Close();
			iErrores++;
			if (iErrores>4) 
			return false;
			pronoApostado.p1=34;pronoApostado.px=33;pronoApostado.p2=33;
		}
		else
		{
			CString s1;recset.GetFieldValue("Ratio1", s1 );
			f1=atof(s1.GetBuffer(1000));
			CString sx;recset.GetFieldValue("Ratiox", sx );
			fx=atof(sx.GetBuffer(1000));
			CString s2;recset.GetFieldValue("Ratio2", s2 );
			f2=atof(s2.GetBuffer(1000));
			pronoApostado.FromRatio(f1,fx,f2);
		}
		pron[i-1] = pronoApostado;
	}
	return true;
}


/**
Cone sto se cambian los nombres de los equpos por sus codigos.

string sql="SELECT * FROM PorcentajesCasasApuestas";
recset.Open ( CRecordset::forwardOnly, sql.c_str(), CRecordset::readOnly );
while ( !recset.IsEOF() )  
{
CString s1;recset.GetFieldValue("Local", s1 );
CString s2;recset.GetFieldValue("Visitante", s2 );
string sid1=getIdFromEquipo(s1.GetBuffer(100));
string sid2=getIdFromEquipo(s2.GetBuffer(100));

if (!(sid1=="35" || sid1=="" || sid1.empty() || sid1==" "))
{
string sql2="UPDATE PorcentajesCasasApuestas SET Local='" + sid1;
sql2= sql2 + "' WHERE Local= '" + s1.GetBuffer(1000)  + "' ";
m_database.ExecuteSQL(sql2.c_str());
}

if (!(sid2=="35" || sid2=="" || sid2.empty() || sid2==" "))
{
string sql2="UPDATE PorcentajesCasasApuestas SET Visitante='" + sid2;
sql2= sql2 + "' WHERE Visitante= '" + s2.GetBuffer(1000)  + "' ";
m_database.ExecuteSQL(sql2.c_str());
}

recset.MoveNext();          // if multiple records to consider, move to next
}

*/
void CQDB::CasarJornadas()
{
	CWaitCursor w;
	int i;
	int j;
	CRecordset recset(&m_database);
	CRecordset recset2(&m_database);
	CRecordset recset3(&m_database);

	// Casa las jornadas de la quiniela con las jornadas de la liga, asignando a los partidos de futbol
	// una jornada quinielistica. 
	for (j=1999;j<2008;j++)
	{
		char temporada[10];sprintf(temporada,"%d",j);
		for (i=1;i<45;i++)
		{
			char jornada[10];sprintf(jornada,"%02d",i);
			string sTemporada=temporada;
			string sJornada=jornada;

			string sql="SELECT IdEquipoLocal,IdEquipoVisitante,Partido from EquiposJornada WHERE Temporada='";
			sql += sTemporada;
			sql += "' AND Jornada = '" + sJornada + "'";
			recset.Open ( CRecordset::forwardOnly, sql.c_str(), CRecordset::readOnly );
			while ( !recset.IsEOF() )  
			{
				CString s1;recset.GetFieldValue("IdEquipoLocal", s1 );
				CString s2;recset.GetFieldValue("IdEquipoVisitante", s2 );
				CString s3;recset.GetFieldValue("Partido", s3 );
				if (s1==CString("33") && s2==CString("138") && CString(sTemporada.c_str())==CString("1999"))
				s1=s1;

				string sql2="SELECT Local,Visitante from ProcentajesCasasApuestas WHERE Local=";
				sql2 += string(s1.GetBuffer(100)) + string(" AND Visitante=") + string(s2.GetBuffer(100));
				sql2 += string(" AND Temporada='") + sTemporada + string("';");
				recset2.Open ( CRecordset::forwardOnly, sql.c_str(), CRecordset::readOnly );
				if (recset2.GetRecordCount()==1)
				{
					string sql3="UPDATE PorcentajesCasasApuestas SET Jornada = '" + sJornada;
					sql3+="' WHERE Local=";
					sql3 += string(s1.GetBuffer(100)) + string(" AND Visitante=") + string(s2.GetBuffer(100));
					sql3 += string(" AND Temporada='") + sTemporada + string("';");
					m_database.ExecuteSQL(sql3.c_str());

					sql3="UPDATE PorcentajesCasasApuestas SET Partido = " + string(s3.GetBuffer(100));
					sql3+=" WHERE Local=";
					sql3 += string(s1.GetBuffer(100)) + string(" AND Visitante=") + string(s2.GetBuffer(100));
					sql3 += string(" AND Temporada='") + sTemporada + string("';");
					m_database.ExecuteSQL(sql3.c_str());
				}
				if (recset2.GetRecordCount()>1)
				{
					sql=sql;
				}

				recset2.Close();
				recset.MoveNext();          // if multiple records to consider, move to next
			}
		recset.Close();
		}
	}
}

vector<string> CQDB::getEquipos()
{
	vector<string> vsEquipos;

	if (m_database.IsOpen())
	{
		string sIdEquipo;
		CString sql;
		sql="SELECT * FROM Equipos";
		CRecordset recset(&m_database);
		recset.Open ( CRecordset::forwardOnly, sql, CRecordset::readOnly );
		while(!recset.IsEOF())
		{
			CString s1;recset.GetFieldValue("Equipo", s1 );
			sIdEquipo=s1.GetBuffer();
			vsEquipos.push_back(sIdEquipo);
			recset.MoveNext();
		}
	}
	sort(vsEquipos.begin(), vsEquipos.end());
	return vsEquipos;
}

bool CQDB::InsertarEquiposPartido(string temporada, string jornada, string partido, int local, int visitante)
{
	return false;
}

