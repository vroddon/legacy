// ColumnasFijasDlg.cpp : implementation file
//

#include "stdafx.h"
#include "qw.h"
#include "ColumnasFijasDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CColumnasFijasDlg dialog


CColumnasFijasDlg::CColumnasFijasDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CColumnasFijasDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CColumnasFijasDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CColumnasFijasDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CColumnasFijasDlg)
	DDX_Control(pDX, IDC_NUMCOLS, m_editNumCols);
	DDX_Control(pDX, IDC_DISTANCIA, m_editDistancia);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CColumnasFijasDlg, CDialog)
	//{{AFX_MSG_MAP(CColumnasFijasDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CColumnasFijasDlg message handlers

BOOL CColumnasFijasDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CColumnasFijasDlg::OnOK() 
{
	CString s;
	m_editDistancia.GetWindowText(s);
	const char *c=s.GetBuffer(1024);
	m_iDistancia=atoi(c);	

	m_editNumCols.GetWindowText(s);
	const char *c2=s.GetBuffer(1024);
	m_iNumCols=atoi(c2);	

	CDialog::OnOK();
}
