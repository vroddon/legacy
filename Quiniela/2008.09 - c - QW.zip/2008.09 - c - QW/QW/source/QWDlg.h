// QWDlg.h : header file
//

#if !defined(AFX_QWDLG_H__1FA46935_859D_4D12_94D8_9F5B56B1B5E2__INCLUDED_)
#define AFX_QWDLG_H__1FA46935_859D_4D12_94D8_9F5B56B1B5E2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#pragma warning (disable:4786)
#include "grid/gridctrl.h"
#include "../lib/qlib/source/apuesta.h"


#include <vector>
#include <string>
#include "afxwin.h"
#include "QWManager.h"
using namespace std;
#pragma warning (disable:4786)
/////////////////////////////////////////////////////////////////////////////
// CQWDlg dialog



class CQWDlg : public CDialog
{
// Construction
public:
	CQWDlg(CWnd* pParent = NULL, class CQWManager *manager=NULL);	// standard constructor
	virtual ~CQWDlg();
// Dialog Data
	//{{AFX_DATA(CQWDlg)
	enum { IDD = IDD_QW_DIALOG };
	CStatic	m_textDistanciaMin;
	CStatic	m_textProb14Media;
	CStatic	m_textApuestaVariantes;
	CStatic	m_textFlag;
	CStatic	m_textpremios10;
	CStatic	m_textpremios11;
	CStatic	m_textpremios12;
	CStatic	m_textpremios13;
	CStatic	m_textpremios14;
	CStatic	m_textprob14;
	CStatic	m_textncols;
	CStatic	m_textnumbercol;
	CStatic	m_textcolumnasel;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CQWDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	virtual LRESULT WindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	//}}AFX_VIRTUAL
	CGridCtrl m_reja;
// Implementation
protected:
	class CProgStatusBar *m_status;
	CFont *m_fontcourier;
	CFont *m_fontgorda;

	void ActualizarDatosDeUI();

	HICON m_hIcon;


	/**
	* Llena todos los componentes posibles
	*/
	void LlenarTodo();

	/**
	* Llena los pronosticos
	*/
	void LlenarPronosticos();

	/**
	* Llena la apuesta
	*/
	void LlenarApuesta();

	/**
	* Llena los partidos
	*/
	void LlenarPartidos();

	/**
	* Llena la solucion
	*/
	void LlenarGanadora();

	/**
	* Llena los premios
	*/
	void LlenarPremios();

	/**
	* Llena el escrutinio
	*/
	void LlenarEscrutinio();

	/**
	* Prepara la reja tipo excel
	*/
	void PrepararReja();

	void LlenarEstadisticasApuesta(class CApuesta *a);

	void LlenarEstadisticasCol(class CColumna *c);

	void LlenarEstadisticasFila(int fila);
	/**
	* Inicializa las temporadas disponibles
	*/
	void InitializeTemporadas();

	/**
	* Devuelve las columnas seleccionadas.
	*/
	vector<CColumna *> getSelCols();

	/**
	* Devuelve las filas seleccionadas (empezando por el 0 hasta el 13)
	*/
	vector<int> getSelFilas();

	void InferEquipos(string partido, int &iLocal, int &iVisitante);


	/**
	* Devuelve temporada y jornada seleccionadas
	* Ej: "1989", "02"
	* 1989 means 1988/189
	*/
	void getSelJornada(string &temporada, string &jornada);





	// Generated message map functions
	//{{AFX_MSG(CQWDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnAyudaAcercaDe();
	afx_msg void OnArchivoAbrirapuesta();
	afx_msg void OnArchivoGuardarapuesta();
	afx_msg void OnArchivoSalir();
	afx_msg void OnInsertarGenerartodas();
	afx_msg void OnInsertarInsertarcolumna();
	afx_msg void OnEliminarEliminartodas();
	afx_msg void OnEliminarQuitarimposibles();
	afx_msg void OnEliminarMinimaprob();
	afx_msg void OnEliminarEliminarcolumna();
	afx_msg void OnEliminarMinimarentabilidad();
	afx_msg void OnEliminarReducirDistancia0();
	afx_msg void OnEliminarReducirDistancia1();
	afx_msg void OnEliminarReducirDistancia2();
	afx_msg void OnEliminarReducirDistancia3();
	afx_msg void OnEliminarReducirDistancia4();
	afx_msg void OnEliminarReducirDistancia5();
	afx_msg void OnEliminarReducirDistancia6();
	afx_msg void OnEliminarReducirDistancia7();
	afx_msg void OnEdicionOrdenar();
	afx_msg void OnEdicionRevalorar();
	afx_msg void OnEscrutinioEscrutar();
	afx_msg void OnArchivoGuardartodo();
	afx_msg void OnInsertarAleatoria();
	afx_msg void OnAnalisisHistograma();
	afx_msg void OnEdicionPegar();
	afx_msg void OnInsertarMasProbable();
	afx_msg void OnAnalisisProbabilidades();
	afx_msg void OnArchivoExportara15();
	afx_msg void OnGridRClick(NMHDR *pNotifyStruct, LRESULT* pResult);
	//}}AFX_MSG
	afx_msg void OnGridEndEdit(NMHDR *pNotifyStruct, LRESULT* pResult);
	afx_msg void OnGridStartEdit(NMHDR *pNotifyStruct, LRESULT* pResult);
	afx_msg void OnGridEndSelChange(NMHDR *pNotifyStruct, LRESULT* /*pResult*/);

	DECLARE_MESSAGE_MAP()
private:
	CQWManager *m_manager;

	vector<int> CQWDlg::getHistogramaRent(int iBaskets);

	afx_msg void OnColumnmenuInsertarcols();
	afx_msg void OnColumnaEliminarcolumna();
	afx_msg void OnCbnSelchangeCbjornada();
	afx_msg void OnCbnSelchangeCbtemporada();
	afx_msg void OnInsertar1aleatoria();
	afx_msg void OnEdicionOrdenaraciertos();
	afx_msg void OnArchivoAbrirtodo();
	afx_msg void OnColumnaQuitar1();
	afx_msg void OnColumnaQuitar2();
	afx_msg void OnColumnaQuitar3();
	afx_msg void OnFilaRedistribuir();
	afx_msg void OnColumnaQuitar4();
	afx_msg void OnColumnaQuitar5();
	afx_msg void OnEdiciOrdenarporrent();
	afx_msg void OnAyudaImportar();
	afx_msg void OnAyudaJoker();
	CStatic m_stPremioTotal;
	CStatic m_stRentabilMed;
	CStatic m_stRecaudacion;
	CStatic m_stPremi14;
	CStatic m_stPremi13;
	CStatic m_stPremi12;
	CStatic m_stPremi11;
	CStatic m_stPremi10;
	CStatic m_stAciertosSelCol;
	CComboBox m_cbTemporada;
	CComboBox m_cbJornada;

//public:
	CStatic m_stPremi15;
	CStatic m_textPremios15;
	CStatic m_stPronosMarca;
	CStatic m_stPrecioApuesta;
	CStatic m_stAcer14;
	CStatic m_stAcer13;
	CStatic m_stAcer12;
	CStatic m_stAcer11;
	CStatic m_stAcer10;
	CStatic m_stAcer15;
	CStatic m_stEquipoLocal;
	CStatic m_stEquipoVisitante;

	afx_msg void OnArchivoGuardarendb();
	afx_msg void OnAyudaImportarapostadas();
public:
	CStatic m_stFilaComments;
	afx_msg void OnBnClickedCalcrentexacta();
	CStatic m_stRentExacta;
	afx_msg void OnBnClickedFijarequipolocal();
	afx_msg void OnArchivoAbrirapuestaNUEVO();
	afx_msg void OnArchivoGuardarapuesta32830();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_QWDLG_H__1FA46935_859D_4D12_94D8_9F5B56B1B5E2__INCLUDED_)
