#include "stdafx.h"

#pragma warning (disable:4786)

#include <math.h>


//QLIB
#include "../lib/qlib/source/conf.h"
#include "../lib/qlib/source/apuesta.h"
#include "../lib/qlib/source/Qutil.h"

//QW
#include "conf.h"
#include "progbar.h"
#include "QW.h"
#include "QWDlg.h"
#include "GetNumberDlg.h"
#include "ColumnasFijasDlg.h"
#include "SaveDBDlg.h"
#include "AboutDlg.h"
#include "qdb.h"
#include "DlgSeleccionEquipo.h"
#include ".\qwdlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
#pragma warning (disable:4786)

/******************   ARCHIVO       ****************************************/
/***************************************************************************/

void CQWDlg::OnArchivoSalir() 
{
	DestroyWindow();
}

void CQWDlg::OnArchivoGuardarendb()
{
	CSaveDBDlg dlg;
	int result=dlg.DoModal();
	if (result==IDCANCEL) 
		return;

	CWaitCursor c;
	if (dlg.m_bSaveApuesta)
	{
		bool bOK=m_manager->m_db->SaveApuesta(m_manager->m_sTemporada,m_manager->m_sJornada,m_manager->m_apuesta);	
		if (!bOK) AfxMessageBox("error guardando apuesta");
	}
	if (dlg.m_bSaveResultado)
	{
		bool bOK=m_manager->m_db->SaveGanadora(m_manager->m_sTemporada.c_str(),m_manager->m_sJornada.c_str(),m_manager->m_ganadora);	
		if (!bOK) AfxMessageBox("error guardando ganadora");
	}
	if (dlg.m_bSavePronostico)
	{
		//		bool bOK=m_manager->m_db->SavePronostico(m_manager->m_sTemporada.c_str(),m_manager->m_sJornada.c_str(),m_manager->m_ganadora);	
		//		if (!bOK) AfxMessageBox("error guardando ganadora");
	}
}


void CQWDlg::OnArchivoExportara15() 
{
	CGetNumberDlg dlg("Escoja el signo del pleno al 15", "Pleno al 15");
	if (dlg.DoModal()!=IDCANCEL)
	{
		ofstream o("apuesta15.txt");
		for (int i=0;i<m_manager->m_apuesta->getSize();i++)
		{
			o << m_manager->m_apuesta->cols[i];
			o << dlg.m_sString.GetBuffer(1024);
			o << '\n';
		}	
	}
}

void CQWDlg::OnArchivoAbrirapuesta() 
{

}

void CQWDlg::OnArchivoGuardarapuesta() 
{

}

void CQWDlg::OnArchivoGuardartodo() 
{
	ActualizarDatosDeUI();
	GuardarPartidos(m_manager->m_partidos);
	GuardarPronostico(CApuesta::pronostico);
	GuardarPronostico(CApuesta::pronosticocateto,"pronosticocateto.txt");
	GuardarApuesta(m_manager->m_apuesta);
	GuardarSolucion(&m_manager->m_ganadora);
}


/******************   INSERTAR       ****************************************/
/***************************************************************************/

void CQWDlg::OnInsertarGenerartodas() 
{
	CWaitCursor relojito;
	delete m_manager->m_apuesta;
	m_manager->m_apuesta = new CApuesta();
	m_manager->m_apuesta->GenerarTodas();
	m_status->OnProgress(0);m_status->SetPaneText(0," ");
	m_status->UpdateWindow();;
	LlenarApuesta();
}

void CQWDlg::OnInsertarInsertarcolumna() 
{
	if (m_manager->m_apuesta->getSize()>=COMBINACIONES)
	{
		AfxMessageBox("N�mero m�ximo de apuestas excedido");
		return;
	}
	CColumna c((long)0);
	m_manager->m_apuesta->InsertarAlloc(c);
	//and we reorder teh position of the new col

	int ncols=m_manager->m_apuesta->getSize();
	CApuesta *m_atmp=new CApuesta(*m_manager->m_apuesta);
	memcpy(&m_atmp->cols[1],m_manager->m_apuesta->cols,(ncols-1)*sizeof(CColumna));
	m_atmp->cols[0]=c;
	memcpy(m_manager->m_apuesta->cols,m_atmp->cols,(ncols)*sizeof(CColumna));
	LlenarApuesta();
}

void CQWDlg::OnInsertarAleatoria() 
{
	CGetNumberDlg dlg("Numero de columnas a generar","Columnas: ");
	dlg.DoModal();
	if (dlg.m_iNumber==-1)
		return;
	if (dlg.m_iNumber<1 || dlg.m_iNumber> 5000000)
		return;
	for (int i=0;i<dlg.m_iNumber;i++)
	{
		CColumna c;
		if (!(i%1000))
			::SendMessage(AfxGetMainWnd()->GetSafeHwnd(),MSGQ_PROGRESS,100*i/dlg.m_iNumber,0);

		c.Random(CApuesta::pronostico);
		m_manager->m_apuesta->InsertarAlloc(c);
	}
	::SendMessage(AfxGetMainWnd()->GetSafeHwnd(),MSGQ_PROGRESS,0,0);
	m_status->SetPaneText(0," ");m_status->OnProgress(0);m_status->UpdateWindow();
	LlenarApuesta();
}

void CQWDlg::OnInsertarMasProbable() 
{

	CColumnasFijasDlg dlg;
	if (dlg.DoModal()==IDCANCEL)
		return;
	int iCols=dlg.m_iNumCols;
	int iDistancia=dlg.m_iDistancia;

	CApuesta *atmp=new CApuesta();
	atmp->GenerarTodas();

	for (int i=0;i<iCols;i++)
	{
		CColumna *c=atmp->getBestUnflagged();	
		if(!c) return;
		atmp->FlagAround(*c,iDistancia);
		m_manager->m_apuesta->InsertarAlloc(*c);
		::SendMessage(AfxGetMainWnd()->GetSafeHwnd(),MSGQ_PROGRESS,100*i/iCols,0);

	}
	::SendMessage(AfxGetMainWnd()->GetSafeHwnd(),MSGQ_PROGRESS,0,0);
	delete atmp;
	LlenarApuesta();
}

/******************   ELIMINAR       ****************************************/
/***************************************************************************/


void CQWDlg::OnEliminarReducirDistancia0() {CWaitCursor r;m_manager->m_apuesta->Filtrar(fDistancia,&make_pair(m_manager->m_apuesta,0));LlenarApuesta();}
void CQWDlg::OnEliminarReducirDistancia1() {CWaitCursor r;m_manager->m_apuesta->Filtrar(fDistancia,&make_pair(m_manager->m_apuesta,1));LlenarApuesta();}
void CQWDlg::OnEliminarReducirDistancia2() {CWaitCursor r;m_manager->m_apuesta->Filtrar(fDistancia,&make_pair(m_manager->m_apuesta,2));LlenarApuesta();}
void CQWDlg::OnEliminarReducirDistancia3() {CWaitCursor r;m_manager->m_apuesta->Filtrar(fDistancia,&make_pair(m_manager->m_apuesta,3));LlenarApuesta();}
void CQWDlg::OnEliminarReducirDistancia4() {CWaitCursor r;m_manager->m_apuesta->Filtrar(fDistancia,&make_pair(m_manager->m_apuesta,4));LlenarApuesta();}
void CQWDlg::OnEliminarReducirDistancia5() {CWaitCursor r;m_manager->m_apuesta->Filtrar(fDistancia,&make_pair(m_manager->m_apuesta,5));LlenarApuesta();}
void CQWDlg::OnEliminarReducirDistancia6() {CWaitCursor r;m_manager->m_apuesta->Filtrar(fDistancia,&make_pair(m_manager->m_apuesta,6));LlenarApuesta();}
void CQWDlg::OnEliminarReducirDistancia7() {CWaitCursor r;m_manager->m_apuesta->Filtrar(fDistancia,&make_pair(m_manager->m_apuesta,7));LlenarApuesta();}

void CQWDlg::OnEliminarMinimarentabilidad() 
{
	CGetNumberDlg dlg("Minima rentabilidad", "Min. rent x100");
	dlg.DoModal();
	if (dlg.m_iNumber!=-1)
	{
		m_manager->m_apuesta->Filtrar(fRentabilidad,(void *)dlg.m_iNumber);
	}
	LlenarApuesta();
}

void CQWDlg::OnEliminarEliminartodas() 
{
	m_manager->m_apuesta->setSize(0);
	LlenarApuesta();
}

void CQWDlg::OnEliminarMinimaprob() 
{
	CGetNumberDlg dlg("Minima probabilidad", "Ej: 1E-6");
	dlg.DoModal();
	if (dlg.m_fNumber!=-1)
	{
		m_manager->m_apuesta->Filtrar(fBajas,(void *)&dlg.m_fNumber);
	}
	LlenarApuesta();
}

void CQWDlg::OnEliminarEliminarcolumna() 
{
	CCellRange cr=m_reja.GetSelectedCellRange();	
	for (int c=cr.GetMinCol()-12;c<cr.GetMaxCol()-11;c++)
		if (c>=0 && c<m_manager->m_apuesta->getSize())
			m_manager->m_apuesta->Remove(cr.GetMinCol()-12);
	LlenarApuesta();
}

void CQWDlg::OnEliminarQuitarimposibles() 
{
	CWaitCursor r;
	m_manager->m_apuesta->Filtrar(fCeros,NULL);
	LlenarApuesta();

}


/******************   EDITAR        ****************************************/
/***************************************************************************/


void CQWDlg::OnEdicionOrdenar() 
{
	CWaitCursor r;
	if (m_manager->m_apuesta->getSize()>100000)
	{
		int i=AfxMessageBox("La operaci�n ser�a demasiado lenta y ha sido suspendida. Debe haber a lo sumo 100,000 columnas\n�Est� seguro de que desea continuar?",MB_YESNO);
		if  (i == IDNO) return;
	}
	m_manager->m_apuesta->Ordenar();
	LlenarApuesta();

}
void CQWDlg::OnEdicionOrdenaraciertos()
{
	CWaitCursor r;
	if (m_manager->m_apuesta->getSize()>100000)
	{
		int i=AfxMessageBox("La operaci�n ser�a demasiado lenta y ha sido suspendida. Debe haber a lo sumo 100,000 columnas\n�Est� seguro de que desea continuar?",MB_YESNO);
		if  (i == IDNO) return;
	}
	m_manager->m_apuesta->OrdenarPorAciertos(m_manager->m_ganadora);
	LlenarApuesta();

}

void CQWDlg::OnEdicionRevalorar() 
{
	CWaitCursor r;

	//Primero se normaliza
	CPronostico ptmp[14];
	NormalizarPronostico(CApuesta::pronostico,ptmp);for (int i=0;i<14;i++) CApuesta::pronostico[i]=ptmp[i];
	NormalizarPronostico(CApuesta::pronosticocateto,ptmp);for (int i=0;i<14;i++) CApuesta::pronosticocateto[i]=ptmp[i];
	int tam=m_manager->m_apuesta->getSize();
	for (int i=0;i<tam;i++)
	{
		if (i%10000==0)
		{
			::SendMessage(AfxGetMainWnd()->GetSafeHwnd(),MSGQ_PROGRESS,100*i/tam,0);
			//			CString cad;cad.Format("%d %d",i,a->getSize());m_rotulo.SetWindowText(cad);
			//			m_progreso.SetPos(100*i/tam);
		}
		//		m_manager->m_apuesta->cols[i].m_valor=(int)m_manager->m_apuesta->cols[i].Valorar(CApuesta::pronostico);
		m_manager->m_apuesta->cols[i].m_fProb=(float)m_manager->m_apuesta->cols[i].Probabilidad14(CApuesta::pronostico,false);
	}
	::SendMessage(AfxGetMainWnd()->GetSafeHwnd(),MSGQ_PROGRESS,0,0);
	//	CString s;	s.Format("%d %d",histograma[30],histograma[90]);AfxMessageBox(s);
	LlenarApuesta();
	LlenarPronosticos();
}

void CQWDlg::OnEdiciOrdenarporrent()
{
	CWaitCursor r;
	if (m_manager->m_apuesta->getSize()>100000)
	{
		int i=AfxMessageBox("La operaci�n ser�a demasiado lenta y ha sido suspendida. Debe haber a lo sumo 100,000 columnas\n�Est� seguro de que desea continuar?",MB_YESNO);
		if  (i == IDNO) return;
	}
	m_manager->m_apuesta->OrdenarPorRent();
	LlenarApuesta();	
}

void CQWDlg::OnEdicionPegar() 
{
	COleDataObject obj;
	if (!obj.AttachClipboard())
		return;
	COleDataObject *pDataObject= &obj;
	HGLOBAL hmem = pDataObject->GetGlobalData(CF_TEXT);
	CMemFile sf((BYTE*) ::GlobalLock(hmem), ::GlobalSize(hmem));
	LPTSTR szBuffer = new TCHAR[::GlobalSize(hmem)];
	if (!szBuffer)
		return;
	sf.Read(szBuffer, ::GlobalSize(hmem));
	::GlobalUnlock(hmem);
	CString strText = szBuffer;
	delete szBuffer;
	strText.LockBuffer();
	vector<string> v;
	CString strLine = strText;
	const char *charText=strLine.GetBuffer(8*1024);
	if (strlen(charText)%14)
		return;
	int columnastot=strlen(charText)/14;
	int columnas=(columnastot-1)/2;
	signo *scc=(signo *)malloc(14*sizeof(signo));
	for (int j=0;j<columnas;j++)
	{

		for (int i=0;i<14;i++)
		{
			char cc=charText[i*columnastot+2*j];
			scc[i]=cc;
		}
		CColumna c(scc);
		m_manager->m_apuesta->InsertarAlloc(c);
	}
	free(scc);
	strText.UnlockBuffer();
	LlenarApuesta();
}

/******************   COLUMNAS/FILAS        ****************************************/
/***************************************************************************/



void CQWDlg::OnColumnmenuInsertarcols()
{
	if (m_manager->m_apuesta->getSize()>=COMBINACIONES)
	{
		AfxMessageBox("N�mero m�ximo de apuestas excedido");
		return;
	}
	CCellRange cr=m_reja.GetSelectedCellRange();	
	int c=cr.GetMinCol()-12;
	if (c>=0 && c<m_manager->m_apuesta->getSize())
	{
		CColumna col=m_manager->m_apuesta->cols[c];
		m_manager->m_apuesta->InsertarAlloc(col);
		LlenarApuesta();
	}
}

void CQWDlg::OnColumnaEliminarcolumna()
{
	if (m_manager->m_apuesta->getSize()>=COMBINACIONES)
	{
		AfxMessageBox("N�mero m�ximo de apuestas excedido");
		return;
	}
	CCellRange cr=m_reja.GetSelectedCellRange();	
	int c=cr.GetMinCol()-12;
	if (c>=0 && c<m_manager->m_apuesta->getSize())
		m_manager->m_apuesta->Remove(c);
	LlenarApuesta();
}

void CQWDlg::InitializeTemporadas()
{
	vector<string> vs=m_manager->m_db->getTemporadas();
	for (unsigned int i=0;i<vs.size();i++)
	{
		m_cbTemporada.AddString(vs[i].c_str());
	}
	m_cbJornada.Clear();
}




void CQWDlg::OnCbnSelchangeCbtemporada()
{
	CString s;
	int i=m_cbTemporada.GetCurSel();CString temporada;
	m_cbTemporada.GetLBText(i,temporada);

	vector<string> jornadas=m_manager->m_db->getJornadas(temporada.GetBuffer(1000));
	m_cbJornada.Clear();
	for (unsigned int i=0;i<jornadas.size();i++)
	{
		m_cbJornada.AddString(jornadas[i].c_str());
	}
	m_cbJornada.SetCurSel(0);OnCbnSelchangeCbjornada();
}

void CQWDlg::OnInsertar1aleatoria()
{
	CColumna c;
	c.Random(CApuesta::pronostico);
	m_manager->m_apuesta->InsertarAlloc(c);
	LlenarApuesta();
}


void CQWDlg::OnArchivoAbrirtodo()
{
	m_manager->LeerArchivos();
	LlenarTodo();
}



void CQWDlg::OnColumnaQuitar1()
{
	//	Quita los vecinos de la columna seleccionada.
	CCellRange cr=m_reja.GetSelectedCellRange();	
	int c=cr.GetMinCol()-12;
	if (c>=0 && c<m_manager->m_apuesta->getSize())
	{
		CColumna col=m_manager->m_apuesta->cols[c];
		m_manager->m_apuesta->removeNeighbours(col,1);
		m_manager->m_apuesta->InsertarAlloc(col);
	}
	LlenarApuesta();
}

void CQWDlg::OnColumnaQuitar2()
{
	//	Quita los vecinos de la columna seleccionada.
	CCellRange cr=m_reja.GetSelectedCellRange();	
	int c=cr.GetMinCol()-12;
	if (c>=0 && c<m_manager->m_apuesta->getSize())
	{
		CColumna col=m_manager->m_apuesta->cols[c];
		m_manager->m_apuesta->removeNeighbours(col,2);
		m_manager->m_apuesta->InsertarAlloc(col);

	}
	LlenarApuesta();
}

void CQWDlg::OnColumnaQuitar3()
{
	CCellRange cr=m_reja.GetSelectedCellRange();	
	int c=cr.GetMinCol()-12;
	if (c>=0 && c<m_manager->m_apuesta->getSize())
	{
		CColumna col=m_manager->m_apuesta->cols[c];
		m_manager->m_apuesta->removeNeighbours(col,3);
		m_manager->m_apuesta->InsertarAlloc(col);
	}
	LlenarApuesta();
}

void CQWDlg::OnFilaRedistribuir()
{
	CCellRange cr=m_reja.GetSelectedCellRange();	
	int rMin=cr.GetMinRow();
	int rMax=cr.GetMaxRow();
	for (int i=rMin-1;i<rMax;i++)
	{
		for (int j=0;j<m_manager->m_apuesta->getSize();j++)
		{
			CColumna c;c.Random(CApuesta::pronostico);
			m_manager->m_apuesta->cols[j].var(i,c.var(i));
		}
	}
	LlenarApuesta();
}

void CQWDlg::OnColumnaQuitar4()
{
	CCellRange cr=m_reja.GetSelectedCellRange();	
	int c=cr.GetMinCol()-12;
	if (c>=0 && c<m_manager->m_apuesta->getSize())
	{
		CColumna col=m_manager->m_apuesta->cols[c];
		m_manager->m_apuesta->removeNeighbours(col,4);
		m_manager->m_apuesta->InsertarAlloc(col);
	}
	LlenarApuesta();
}

void CQWDlg::OnColumnaQuitar5()
{
	CCellRange cr=m_reja.GetSelectedCellRange();	
	int c=cr.GetMinCol()-12;
	if (c>=0 && c<m_manager->m_apuesta->getSize())
	{
		CColumna col=m_manager->m_apuesta->cols[c];
		m_manager->m_apuesta->removeNeighbours(col,5);
		m_manager->m_apuesta->InsertarAlloc(col);
	}
	LlenarApuesta();
}



void CQWDlg::OnAyudaImportar()
{
	m_manager->m_db->Actualizar();
}

//Calcular el histograma de rentabilidades.
//Dedica el 10% de baskets a las rentabilidades entre 0 y 1
//FUNCION OK!
vector<int> CQWDlg::getHistogramaRent(int iBaskets)
{
	vector<int> vHisto;
	vHisto.resize(iBaskets);

	for (int i=0;i<iBaskets;i++) vHisto[i]=0;
	int total=m_manager->m_apuesta->getSize();
	for (int i=0;i< total;i++)
	{
		::SendMessage(AfxGetMainWnd()->GetSafeHwnd(),MSGQ_PROGRESS,100*i/total,0);
		float f=m_manager->m_apuesta->cols[i].Rentabilidad(CApuesta::pronostico, CApuesta::pronosticocateto);
		int basket=(int)(f*iBaskets/10);
		if (basket>(iBaskets-1)) basket=iBaskets-1;
		vHisto[basket]++;
	}
	::SendMessage(AfxGetMainWnd()->GetSafeHwnd(),MSGQ_PROGRESS,0,0);

	return vHisto;
}


void CQWDlg::OnAyudaJoker()
{

	vector<int> b=getHistogramaRent(50);

	FILE *fi=fopen("C:\\salida.txt","w");
	for (int i=0;i<50;i++)
		fprintf(fi, " %d ", b[i]);
	fclose(fi);


	/*
	CCellRange cr=m_reja.GetSelectedCellRange();	
	int c=cr.GetMinCol()-12;
	CColumna col;
	if (c>=0 && c<m_manager->m_apuesta->getSize())
	{
	col=m_manager->m_apuesta->cols[c];
	}else return;

	//Rentabilidad por nivel
	CString s;
	s.Format("%f",col.getProbabilidadReal(CApuesta::pronostico));
	AfxMessageBox(s);


	double renta0=col.getRentabilidadPorNivel(0);
	double renta1=col.getRentabilidadPorNivel(1);
	double renta2=col.getRentabilidadPorNivel(2);
	double renta3=col.getRentabilidadPorNivel(3);
	double renta4=col.getRentabilidadPorNivel(4);

	double rentatotal=renta0+renta1+renta2+renta3+renta4;
	s.Format("%f",rentatotal);
	AfxMessageBox(s);

	return;


	//	m_manager->m_db->Joker();
	/*
	CWaitCursor c;
	FILE *f14=fopen("C:\\p14.txt","w");
	FILE *f13=fopen("C:\\p13.txt","w");
	FILE *f12=fopen("C:\\p12.txt","w");
	FILE *f11=fopen("C:\\p11.txt","w");
	FILE *f10=fopen("C:\\p10.txt","w");

	for (int m=1;m<38;m++)
	{
	string temporada="2005";
	string jornada="01";
	char buf[23];sprintf(buf,"%02d",m);jornada=buf;

	m_manager->m_db->LoadPremios(temporada.c_str(),jornada.c_str());

	CPronostico cateto[14];
	CPremios premiosEstimados;
	CColumna ganadora=m_manager->m_db->LoadGanadora(temporada.c_str(),jornada.c_str(),NULL);
	//		bool bOK=m_manager->m_db->LoadPronosticoApostado(temporada.c_str(),jornada.c_str(),cateto);
	bool bOK=m_manager->m_db->LoadPronosticoApostado(temporada.c_str(),jornada.c_str(),cateto);

	premiosEstimados.Estimar(cateto, ganadora, m_manager->m_premios.iRecaudacion);

	fprintf(f14,"%s\t%s\t%.0f\t%.0f\n", temporada.c_str(),jornada.c_str(),(float)premiosEstimados.m_iAcertantes14,(float)m_manager->m_premios.m_iAcertantes14);
	fprintf(f13,"%s\t%s\t%.0f\t%.0f\n", temporada.c_str(),jornada.c_str(),(float)premiosEstimados.m_iAcertantes13,(float)m_manager->m_premios.m_iAcertantes13);
	fprintf(f12,"%s\t%s\t%.0f\t%.0f\n", temporada.c_str(),jornada.c_str(),(float)premiosEstimados.m_iAcertantes12,(float)m_manager->m_premios.m_iAcertantes12);
	fprintf(f11,"%s\t%s\t%.0f\t%.0f\n", temporada.c_str(),jornada.c_str(),(float)premiosEstimados.m_iAcertantes11,(float)m_manager->m_premios.m_iAcertantes11);
	fprintf(f10,"%s\t%s\t%.0f\t%.0f\n", temporada.c_str(),jornada.c_str(),(float)premiosEstimados.m_iAcertantes10,(float)m_manager->m_premios.m_iAcertantes10);
	}
	fclose(f14);
	fclose(f13);
	fclose(f12);
	fclose(f11);
	fclose(f10);


	//este c�digo compara la 
	CCellRange cr=m_reja.GetSelectedCellRange();	
	int icol =cr.GetMinCol()-12;
	CColumna colorigin=m_manager->m_apuesta->cols[icol];

	colorigin=m_manager->m_ganadora;
	vector<CColumna> vc=colorigin.getVecinos(4);
	float probfinal=0;
	for (unsigned int i=0;i<vc.size();i++)
	{
	//		m_manager->m_apuesta->InsertarAlloc(vc[i]);

	probfinal = probfinal + pow((float)10,(float)vc[i].Valorar(CApuesta::pronosticocateto)/10);
	}
	probfinal=(float)log(probfinal) / (float)log((float)10);

	LlenarApuesta();
	return;
	/*
	m_manager->m_db->ImportMarca();
	return;
	FILE *f=fopen("C:\\res.txt","w");
	for (int k=2007;k>=2005;k--)
	{
	char buf2[10];sprintf(buf2,"%d",k);
	string temporada=buf2;
	vector<string> vjornadas=m_manager->m_db->getJornadas(temporada);

	for (unsigned int i=0;i<vjornadas.size();i++)
	{
	string jornada=vjornadas[i];
	//char buf[10];sprintf(buf,"%02d",i);jornada=buf;

	//OBTENEMOS PORCENTAJES
	m_manager->m_db->LoadPronosticoCateto(temporada.c_str(),jornada.c_str(),CApuesta::pronosticocateto);
	m_manager->m_db->getPorcentajeEstimado(temporada.c_str(),jornada.c_str(),CApuesta::pronostico);

	//OBTENEMOS GANADORA
	signo pleno15;
	m_manager->m_ganadora=m_manager->m_db->LoadGanadora(temporada.c_str(),jornada.c_str(),&pleno15);

	//OBTEneMOS PREMIOS
	m_manager->m_db->LoadPremios(temporada.c_str(),jornada.c_str());

	fprintf(f,"%s \t %s \t ", temporada.c_str(),jornada.c_str());
	float f1=m_manager->m_ganadora.Probabilidad14(CApuesta::pronostico);
	float f2=m_manager->m_ganadora.Probabilidad14(CApuesta::pronosticocateto);
	fprintf(f,"%.2f \t %.2f\n",f1,f2);
	/*
	delete m_manager->m_apuesta;
	m_manager->m_apuesta = new CApuesta();
	m_manager->m_apuesta->GenerarTodas();
	m_status->OnProgress(0);m_status->SetPaneText(0,"",1);
	m_status->UpdateWindow();
	//solo las primeras
	m_manager->m_apuesta->Filtrar(fBajas,(void *)-80);
	//		m_manager->m_apuesta->Filtrar(fAltas,(void *)-60);

	//solo las buenas
	m_manager->m_apuesta->Filtrar(fRentabilidad,(void *)1000);
	//solo algunas

	OnEscrutinioEscrutar();
	m_status->SetPaneText(1,jornada.c_str(),1);

	//		LlenarEstadisticasApuesta(m_manager->m_apuesta);
	LlenarPremios();
	fprintf(f,"%s - %s ", temporada.c_str(),jornada.c_str());
	fprintf(f, "%2d\t%d\t%d\n",i,m_manager->m_apuesta->getSize(),m_manager->m_apuesta->m_iPremioTotal);

	}
	}
	m_status->SetPaneText(0,".",1);
	m_status->SetPaneText(1,"listo",1);

	fclose(f);
	LlenarApuesta();
	LlenarPronosticos();
	LlenarGanadora();
	LlenarPremios();
	//	int catorce, trece, doce, once, diez;
	//	m_manager->m_apuesta->Escrutar(m_manager->m_ganadora,&catorce, &trece, &doce, &once, &diez);
	*/
}



void CQWDlg::OnAyudaImportarapostadas()
{
	m_manager->m_db->ImportarJornadasApostadas();
}


void CQWDlg::OnBnClickedCalcrentexacta()
{
	CWaitCursor reloj;

	CCellRange cr=m_reja.GetSelectedCellRange();	
	int c=cr.GetMinCol()-12;
	CColumna col;
	if (c>=0 && c < m_manager->m_apuesta->getSize())
	{
		col=m_manager->m_apuesta->cols[c];
		float f=m_manager->m_apuesta->cols[c].getRentabilidad(false);
		CString s;
		s.Format("La rentabilidad es exactamente:\n%.03f",f);
		AfxMessageBox(s,MB_OK | MB_ICONINFORMATION);
		LlenarEstadisticasCol(&m_manager->m_apuesta->cols[c]);
	}else return;
}

void CQWDlg::InferEquipos(string sPartido, int &iLocal, int &iVisitante)
{
	const char *partidos = sPartido.c_str();
	char local[128];local[0]=0;
	char visitante[128];visitante[0]=0;
	int tam=strlen(partidos);
	int dire=0;
	for (int i=0;i<tam;i++)
	{
		char c[2];c[0]=partidos[i];c[1]=0;
		if (c[0]=='-') dire++;
		else if (dire==0 && c[0]!=' ') strcat(local,c);
		else if (dire==1 && c[0]!=' ') strcat(visitante,c);
	}
	iLocal = atoi(m_manager->m_db->getIdFromEquipo(local).c_str());
	iVisitante = atoi(m_manager->m_db->getIdFromEquipo(visitante).c_str());
}

void CQWDlg::OnBnClickedFijarequipolocal()
{

	vector<int> vi=getSelFilas();
	if (vi.size()!=1) return; int fila=vi[0];
	char partido[10];sprintf(partido,"%d", fila+1);
	string temporada, jornada;
	getSelJornada(temporada,jornada);

	int iLocal, iVisitante;
	CString partidillo=m_reja.GetItemText(fila+1,2);
	InferEquipos(partidillo.GetBuffer(1000),iLocal, iVisitante);

	CDlgSeleccionEquipo sel(this,m_manager);
	if (iLocal!=0) sel.m_sEquipoL= m_manager->m_db->getEquipoFromId(iLocal);
	if (iVisitante!=0) sel.m_sEquipoV = m_manager->m_db->getEquipoFromId(iVisitante);
	if (sel.DoModal()==IDCANCEL) return;

	if (AfxMessageBox("Est� usted seguro?", MB_YESNO | MB_ICONQUESTION)==IDNO) return;
	CString sql;

	int local, visitante;

	local=atoi(m_manager->m_db->getIdFromEquipo(sel.m_sEquipoL).c_str());
	visitante=atoi(m_manager->m_db->getIdFromEquipo(sel.m_sEquipoV).c_str());

	m_manager->m_db->InsertarEquiposPartido(temporada, jornada, partido, local, visitante);


	//	m_manager->m_partidos
}



void CQWDlg::OnEscrutinioEscrutar() 
{
	ActualizarDatosDeUI();
	m_manager->m_apuesta->Escrutar(m_manager->m_ganadora,UNO,m_manager->m_premios);
	LlenarEscrutinio();
	m_status->UpdateWindow();
}



void CQWDlg::OnAnalisisHistograma() 
{
	/*
	CWaitCursor wc;
	CString s;
	char *a=(char *)malloc(1000);
	vector<int> v=m_manager->m_apuesta->getHistograma(30);	
	for (unsigned int i=0;i<v.size();i++)
	{
	sprintf(a,"%d ",v[i]);
	s=s+CString(a);
	}
	AfxMessageBox(s);
	free(a);
	*/
}

void CQWDlg::OnAnalisisProbabilidades() 
{
	int catorce, trece, doce, once, diez;
	m_manager->m_apuesta->Probabilidades(&catorce, &trece, &doce, &once, &diez,10);
	char a[1024], a14[128],a13[128],a12[128],a11[128],a10[128];
	sprintf(a14,"De 14: %d\n",catorce);
	sprintf(a13,"De 13: %d\n",trece);
	sprintf(a12,"De 12: %d\n",doce);
	sprintf(a11,"De 11: %d\n",once);
	sprintf(a10,"De 10: %d\n",diez);
	string s=string(a14)+string(a13)+string(a12)+string(a11)+string(a10);
	AfxMessageBox(s.c_str());
}

void CQWDlg::OnAyudaAcercaDe()
{
	CAboutDlg dlg;
	dlg.DoModal();
}



//CALCULA LOS PREMIOS POR UNA TEMPORADA HABIENDO JUGADO LO RENTABLE
/*
CString temporada="2004/2005";
FILE *fi=fopen("C:\\quiniela0405m.txt","w");
for (int iJornada=1;iJornada<=42;iJornada++)
{
	CString jornada; jornada.Format("%02d",iJornada);
	m_manager->SeleccionarJornada(temporada, jornada);
	m_manager->m_apuesta->GenerarTodas();
	//		m_manager->m_apuesta->Filtrar(fRentabilidad,(void *)(200));
	m_manager->m_apuesta->Ordenar();
	int iPosition=m_manager->m_apuesta->getPosition(m_manager->m_ganadora);
	m_manager->m_apuesta->OrdenarPorRent();
	int iPositionRenta= m_manager->m_apuesta->getPosition(m_manager->m_ganadora);
//			m_manager->m_apuesta->Escrutar(m_manager->m_ganadora,UNO,m_manager->m_premios);
//	LlenarTodo();
//	LlenarEscrutinio();
//	LlenarPremios();
//	int apostado=m_manager->m_apuesta->getSize()/2;
//	int premio=m_manager->m_apuesta->m_iPremioTotal;
//	fprintf(fi,"%s\t%s\t%d\t%d\n",m_manager->m_sTemporada.c_str(), m_manager->m_sJornada.c_str(),premio,apostado);
	
	fprintf(fi,"%s\t%s\t%d\t%d\t%d\n",m_manager->m_sTemporada.c_str(), m_manager->m_sJornada.c_str(),iPosition,iPositionRenta,m_manager->m_premios.iPremio14);
}


fclose(fi);

return ;
*/