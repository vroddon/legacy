// DlgSeleccionEquipo.cpp: archivo de implementaci�n
//

#include "stdafx.h"
#include "QW.h"
#include "DlgSeleccionEquipo.h"
#include ".\dlgseleccionequipo.h"
#include "qdb.h"
#include "GetNumberDlg.h"
// Cuadro de di�logo de CDlgSeleccionEquipo

IMPLEMENT_DYNAMIC(CDlgSeleccionEquipo, CDialog)
CDlgSeleccionEquipo::CDlgSeleccionEquipo(CWnd* pParent /*=NULL*/, CQWManager *manager) : CDialog(CDlgSeleccionEquipo::IDD, pParent)
{
	m_manager=manager;
	m_sEquipoL="";
	m_sEquipoV="";
}

CDlgSeleccionEquipo::~CDlgSeleccionEquipo()
{

}

void CDlgSeleccionEquipo::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LISTAEQUIPOS, m_listEquipos);
	DDX_Control(pDX, IDC_LISTAEQUIPOS2, m_listEquipos2);
}


BEGIN_MESSAGE_MAP(CDlgSeleccionEquipo, CDialog)
	ON_BN_CLICKED(IDOK, OnBnClickedOk)
	ON_BN_CLICKED(IDOK2, OnBnClickedOk2)
	ON_BN_CLICKED(IDOK3, OnBnClickedOk3)
END_MESSAGE_MAP()


// Controladores de mensajes de CDlgSeleccionEquipo

void CDlgSeleccionEquipo::OnBnClickedOk()
{
	int i=m_listEquipos.GetCurSel();
	int j=m_listEquipos2.GetCurSel();

	if (i!=-1 && j!=-1 && j!=i)
	{
		CString s;
		m_listEquipos.GetText(i,s);m_sEquipoL=s.GetBuffer(1000);
		m_listEquipos2.GetText(j,s);m_sEquipoV=s.GetBuffer(1000);
	}
	OnOK();
}

BOOL CDlgSeleccionEquipo::OnInitDialog()
{
	CDialog::OnInitDialog();
	m_listEquipos.ResetContent();
	vector<string> vsEquipos=m_manager->m_db->getEquipos();
	for (int i=0;i<vsEquipos.size();i++)
	{
		m_listEquipos.InsertString(i,vsEquipos[i].c_str());
		m_listEquipos2.InsertString(i,vsEquipos[i].c_str());
	}
	m_listEquipos.SelectString(0,m_sEquipoL.c_str());
	m_listEquipos2.SelectString(0,m_sEquipoV.c_str());

	return TRUE;  // return TRUE  unless you set the focus to a control
}
void CDlgSeleccionEquipo::OnBnClickedOk2()
{
	CDialog::OnCancel();
}

void CDlgSeleccionEquipo::OnBnClickedOk3()
{
	CGetNumberDlg dlg("Nuevo equipo", "Elija el nombre");
	if (dlg.DoModal()!=IDCANCEL)
	{
	}
}
