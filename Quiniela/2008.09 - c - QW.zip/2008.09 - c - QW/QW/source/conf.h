#pragma once
//HOLA MUNDO DESDE EL PORTATIL.
#define MAXCOLSHOWN 512
#define MSGQ_PROGRESS WM_USER + 1
#define VERSION "4.10"
#define DBFILE "qvroddon.mdb"
//esto es desde el fijo
