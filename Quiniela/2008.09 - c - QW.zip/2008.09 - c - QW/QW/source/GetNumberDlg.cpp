// minprobdlg.cpp : implementation file
//

#include "stdafx.h"
#include "qw.h"
#include "GetNumberDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CGetNumberDlg dialog


CGetNumberDlg::CGetNumberDlg(CString titulo, CString texto, CWnd* pParent /*=NULL*/)	: CDialog(CGetNumberDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CGetNumberDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_titulo=titulo;
	m_texto=texto;
	m_iNumber=-1;
	m_fNumber=-1;
	m_sString="";
}


void CGetNumberDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CGetNumberDlg)
	DDX_Control(pDX, IDC_TEXTO, m_textText);
	DDX_Control(pDX, IDC_MINPROB, m_editminprob);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CGetNumberDlg, CDialog)
	//{{AFX_MSG_MAP(CGetNumberDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGetNumberDlg message handlers

void CGetNumberDlg::OnOK() 
{
	CString s;
	m_editminprob.GetWindowText(s);
	m_sString=s;
	const char *c=s.GetBuffer(1024);
	m_iNumber=atoi(c);
	m_fNumber=atof(c);
	CDialog::OnOK();
}

BOOL CGetNumberDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	m_editminprob.SetWindowText("50");	
	m_editminprob.SetFocus();
	m_textText.SetWindowText(m_texto);
	SetWindowText(m_titulo);


	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CGetNumberDlg::OnCancel() 
{
	m_iNumber=-1;
	m_fNumber=-1;
	m_sString="";
	CDialog::OnCancel();
}
