#pragma once
#include <string>

#include "conf.h"
#include "../lib/qlib/source/conf.h"
#include "../lib/qlib/source/apuesta.h"
#include "../lib/qlib/source/Qutil.h"


using namespace std;


class CQWManager
{
public:
	CQWManager();
	~CQWManager();

	/**
	* Intenta leer los archivos predefinidos
	*/
	void LeerArchivos();

	/**
	* Carga los datos que sean necesarios para la temporada/jornada
	* por ejemplo: "1988/1989", "05"
	* Devuelve true si tiene datos de pronostico y de pronostico-cateto.
	*/
	bool SeleccionarJornada(CString temporada, CString jornada);

	class CQDB *m_db;
	class CApuesta *m_apuesta;
	vector<string> m_partidos;
	CColumna m_ganadora;
	CPremios m_premios;

	string m_sJornada;		//por ejemplo
	string m_sTemporada;
};

