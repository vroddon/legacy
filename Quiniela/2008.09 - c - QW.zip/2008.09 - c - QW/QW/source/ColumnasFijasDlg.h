#if !defined(AFX_COLUMNASFIJASDLG_H__937C908C_5055_433C_8B3D_70E88342F2D1__INCLUDED_)
#define AFX_COLUMNASFIJASDLG_H__937C908C_5055_433C_8B3D_70E88342F2D1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ColumnasFijasDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CColumnasFijasDlg dialog

class CColumnasFijasDlg : public CDialog
{
// Construction
public:
	CColumnasFijasDlg(CWnd* pParent = NULL);   // standard constructor
	int m_iNumCols;
	int m_iDistancia;
// Dialog Data
	//{{AFX_DATA(CColumnasFijasDlg)
	enum { IDD = IDD_COLUMNASFIJAS };
	CEdit	m_editNumCols;
	CEdit	m_editDistancia;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CColumnasFijasDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CColumnasFijasDlg)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_COLUMNASFIJASDLG_H__937C908C_5055_433C_8B3D_70E88342F2D1__INCLUDED_)
