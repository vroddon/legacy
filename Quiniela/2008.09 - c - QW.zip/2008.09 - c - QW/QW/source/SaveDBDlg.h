#pragma once
#include "afxwin.h"

class CSaveDBDlg : public CDialog
{
	DECLARE_DYNAMIC(CSaveDBDlg)
public:
	bool m_bSaveApuesta;
	bool m_bSaveResultado;
	bool m_bSavePronostico;
	bool m_bSavePartidos;

	CSaveDBDlg(CWnd* pParent = NULL);   // Constructor est�ndar
	virtual ~CSaveDBDlg();

	enum { IDD = IDD_DBDLG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // Compatibilidad con DDX o DDV

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedOk();
	CButton m_cbApuesta;
	CButton m_cbResultados;
	CButton m_cbPronostico;
	CButton m_cbPartidos;
};
