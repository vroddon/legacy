#include <stdafx.h>

#include "../lib/qlib/source/conf.h"
#include "../lib/qlib/source/apuesta.h"
#include "../lib/qlib/source/Qutil.h"

#include "QWManager.h"
#include "conf.h"
#include "QDB.h"


CQWManager::CQWManager()
{
	m_apuesta= new CApuesta(0);
	m_db = new CQDB(this, DBFILE);
}

CQWManager::~CQWManager()
{
	delete m_apuesta;
}

void CQWManager::LeerArchivos()
{
	LeerApuesta(m_apuesta);
	LeerPronostico(CApuesta::pronostico);
	LeerPronostico(CApuesta::pronosticocateto,"pronosticocateto.txt");
	LeerPartidos(m_partidos);
	LeerSolucion(&m_ganadora);
}

string getTemporada04FromTemporada08(CString temporada)
{
	char buf[10];memset(buf,0,10);memcpy(buf,temporada.GetBuffer(100)+5,4);
	return buf;
}
//Tengo que aclarar aqui o en otro sitio de donde demonios se carga el pronosticocateto etc.
//OJO!!
bool CQWManager::SeleccionarJornada(CString temporada, CString jornada)
{
	bool bOK;

//	char buf[10];memset(buf,0,10);memcpy(buf,temporada.GetBuffer(100)+5,4);
	m_sTemporada=getTemporada04FromTemporada08(temporada);;
	m_sJornada=jornada;

	//CARGAMOS LOS PARTIDOS.
	bOK=m_db->LoadPartidos(temporada, jornada);

	//CARGAMOS EL RESULTADO
	m_ganadora=m_db->LoadGanadora(m_sTemporada.c_str(), jornada);

	//CARGAMOS LOS PRONOSTICOS
	m_db->LoadPronosticos(temporada, jornada);
//	bOK=m_db->LoadPronosticos(temporada, jornada);
	bOK = m_db->LoadPronosticoMarca(temporada,jornada,CApuesta::pronosticocateto);

	//Esto lo carga de lo apostado
//	bOK=m_db->LoadPronosticoApostado(temporada.GetBuffer(100),jornada.GetBuffer(100),CApuesta::pronosticocateto);

	if (!bOK) m_apuesta->ResetPronostico(CApuesta::pronosticocateto);

	//CARGAMOS LOS PREMIOS
	m_db->LoadPremios(m_sTemporada.c_str(), m_sJornada.c_str());

	//CARGAMOS LA APUESTA
	m_db->LoadApuesta(m_sTemporada,m_sJornada, m_apuesta);

	return bOK;
}




