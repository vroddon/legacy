#pragma once
#include <vector>
#include <string>

#include "../lib/qlib/source/apuesta.h"

using namespace std;

class CQDB
{
public:
	CQDB(class CQWManager *manager, CString s="qvroddon.mdb");
	~CQDB();

	void Actualizar();

	vector<string> getJornadas(string sTemporada);
	vector<string> getTemporadas();

	/**
	* Dado un nombre de equipo ("DEPORTIVO"), devuelve su ID (13)
	*/
	string getIdFromEquipo(string sEquipo);

	/**
	* Dado un ID (13) devuelve el nombre de equipo ("DEPORTIVO")
	*/
	string getEquipoFromId(int id);

	/**
	*/
	string InsertEquipo(string sEquipo);

	/**
	* Carga los partidos de "JornadasLosilla". temporada dada en formato corto o largo.
	*/
	bool LoadPartidos(CString temporada, CString jornada );

	/**
	*	Carga la columna ganadora de la tabla Ganadoras
	*/
	CColumna LoadGanadora(CString temporada, CString jornada, signo *pleno15=NULL);

	/**
	* Graba la columna
	*/
	bool SaveGanadora(CString temporada, CString jornada, CColumna ganadora);

	/**
	* Lee el pronostico de Losilla. Son enteros.
	*/
	void LoadPronosticos(CString temporada, CString jornada);

	/**
	* Lee los premios de la tabla PREMIOS
	* Lee el precio de la tabla PRECIO
	* Lee los acertantes de la tabla HISTORICOS
	*/
	bool LoadPremios(CString temporada, CString jornada);

	/**
	* Carga el pronostico apostado en quinielista.com
	*/
	bool LoadPronosticoApostado(string temporada,string jornada,  class CPronostico[14]);

	/**
	* Porcentajes estimados por Eduardo Losilla, y dados en enteros.
	*/
	bool getPorcentajeEstimado(string temporada,string jornada, class CPronostico *);

	/**
	*
	*/
	bool LoadPronosticoApuestas(string temporada, string jornada, class CPronostico[14], int &iErrores);

	bool InsertarEquiposPartido(string temporada, string jornada, string partido, int local, int visitante);


	float EvaluarPronosticoTemporada(string sTemporada);

	/**
	* Importa el pronostico de los lectores de marca
	*/
	void ImportMarca();

	/**
	* Carga de DB el pronostico de los lectores de Marca
	*/
	bool LoadPronosticoMarca(CString temporada, CString jornada, CPronostico pron[14]);


	bool SaveApuesta(string temporada,string jornada,class CApuesta *apuesta);	
	bool LoadApuesta(string temporada,string jornada, class CApuesta *apuesta);
	pair<string,string> getEquipos(string sTemporada, string sJornada, int iPartido);
	vector<string> getEquipos();

	bool SavePronostico(CString temporada, CString jornada, CPronostico p[14]);


	void ImportarJornadasApostadas();
	void Joker();
	void CasarJornadas();


private:
	CString getDriver();
	string DescargarApostadas(string jornada, string temporada);

	/**
	* Actualiza la tabla de losilla.
	*/
	void ImportarJornadasLosilla(CString archivo);
	void ImportJugadasXML(string sFile);


	CString m_archivo;
	class CQWManager *m_manager;
	CString m_sDsn;
	CDatabase m_database;
};

/*
UPDATE PorcentajesCasasApuestas
SET Local = 'R.MADRID'
WHERE Local = 'Real Madrid';

*/