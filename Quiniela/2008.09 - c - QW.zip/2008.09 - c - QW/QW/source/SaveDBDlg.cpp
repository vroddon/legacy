// E:\Proyectos\Personal\Quiniela\QW\source\SaveDBDlg.cpp: archivo de implementaci�n
//

#include "stdafx.h"
#include "QW.h"
//#include "E:\Proyectos\Personal\Quiniela\QW\source\SaveDBDlg.h"
#include ".\savedbdlg.h"


// Cuadro de di�logo de CSaveDBDlg

IMPLEMENT_DYNAMIC(CSaveDBDlg, CDialog)
CSaveDBDlg::CSaveDBDlg(CWnd* pParent /*=NULL*/) : CDialog(CSaveDBDlg::IDD, pParent)
{
}

CSaveDBDlg::~CSaveDBDlg()
{
}

void CSaveDBDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_CBAPUESTA, m_cbApuesta);
	DDX_Control(pDX, IDC_CBSOLUCION, m_cbResultados);
	DDX_Control(pDX, IDC_CBPRONOSTICOS, m_cbPronostico);
	DDX_Control(pDX, IDC_CBPartidos, m_cbPartidos);
}


BEGIN_MESSAGE_MAP(CSaveDBDlg, CDialog)
	ON_BN_CLICKED(IDOK, OnBnClickedOk)
END_MESSAGE_MAP()


// Controladores de mensajes de CSaveDBDlg

void CSaveDBDlg::OnBnClickedOk()
{
	m_bSaveApuesta = m_cbApuesta.GetCheck();
	m_bSaveResultado = m_cbResultados.GetCheck();
	m_bSavePartidos= m_cbPartidos.GetCheck();
	m_bSavePronostico= m_cbPronostico.GetCheck();
	OnOK();
}
